#!/usr/bin/env python3

"""
表现层接口定义
统一使用Polars DataFrame作为数据格式
"""

from typing import Any, Dict, List

import polars as pl


class IView:
    """视图接口，定义视图更新和消息显示方法"""

    def update_chart(self, data: pl.DataFrame, indicators: List[str] | None = None, **params):
        """更新图表数据

        Args:
            data: 图表数据（Polars DataFrame）
            indicators: 指标列表
            **params: 图表更新参数
        """
        raise NotImplementedError("子类必须实现此方法")

    def show_message(self, message: str, message_type: str = 'info', title: str | None = None):
        """显示消息

        Args:
            message: 消息内容
            message_type: 消息类型，可选值：'info'（信息）、'warning'（警告）、'error'（错误）、'success'（成功）
            title: 消息标题
        """
        raise NotImplementedError("子类必须实现此方法")

    def update_progress(self, progress: int, message: str | None = None):
        """更新进度

        Args:
            progress: 进度值（0-100）
            message: 进度消息
        """
        raise NotImplementedError("子类必须实现此方法")

    def clear_progress(self):
        """清除进度显示"""
        raise NotImplementedError("子类必须实现此方法")

    def show_loading(self, visible: bool, message: str | None = None):
        """显示或隐藏加载指示器

        Args:
            visible: 是否显示加载指示器
            message: 加载消息
        """
        raise NotImplementedError("子类必须实现此方法")


class IController:
    """控制器接口，定义用户交互事件处理方法"""

    def on_stock_selected(self, stock_code: str, **params):
        """处理股票选择事件

        Args:
            stock_code: 选中的股票代码
            **params: 其他参数
        """
        raise NotImplementedError("子类必须实现此方法")

    def on_indicator_selected(self, indicator_type: str, **params):
        """处理指标选择事件

        Args:
            indicator_type: 选中的指标类型
            **params: 指标参数
        """
        raise NotImplementedError("子类必须实现此方法")

    def on_timeframe_changed(self, timeframe: str):
        """处理时间周期变化事件

        Args:
            timeframe: 新的时间周期
        """
        raise NotImplementedError("子类必须实现此方法")

    def on_chart_type_changed(self, chart_type: str):
        """处理图表类型变化事件

        Args:
            chart_type: 新的图表类型
        """
        raise NotImplementedError("子类必须实现此方法")

    def on_signal_clicked(self, signal: Dict[str, Any]):
        """处理信号点击事件

        Args:
            signal: 信号数据
        """
        raise NotImplementedError("子类必须实现此方法")

    def on_refresh_data(self):
        """处理刷新数据事件"""
        raise NotImplementedError("子类必须实现此方法")

    def on_backtest_start(self, strategy: str, **params):
        """处理回测开始事件

        Args:
            strategy: 策略名称
            **params: 回测参数
        """
        raise NotImplementedError("子类必须实现此方法")


