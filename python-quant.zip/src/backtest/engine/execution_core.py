#!/usr/bin/env python3

"""
回测执行内核 —— 撮合、T+1、整手、风控、成本、权益估值的唯一实现。

单票回测（BacktestEngine）与组合回测（PortfolioBacktestEngine）都只是
同一内核的参数化封装：

    单票 = 一个标的 + 全部初始资金
    组合 = 多标的 + 等权分配

A 股交易语义只允许在本模块修改，禁止在具体引擎里再写一份：

    1. t 日收盘后生成的信号，延迟到 t+1 日以开盘价成交（避免未来函数）
    2. 买入股数按 lot_size（默认 100 股）整数倍向下取整
    3. 买入成本在下单当时扣除，卖出所得叠加回剩余现金（不能覆盖）
    4. 开盘价触及涨停不可买、触及跌停不可卖、停牌（成交量为 0）不可交易
    5. 涨跌停幅度按证券代码自适应（主板 10%、创业板/科创板 20%、北交所 30%、ST 5%）
"""

from __future__ import annotations

import math
from typing import Any, Dict, List

import polars as pl
from loguru import logger

from src.backtest.costs.cost_model import CostModel
from src.backtest.performance.performance_analyzer import PerformanceAnalyzer
from src.risk import Order as RiskOrder
from src.risk import Portfolio as RiskPortfolio
from src.risk import RiskEngine


class ExecutionRules:
    """A 股撮合规则：涨跌停幅度推导 + 当日可交易性判定。"""

    #: 价格空间比较的浮点噪声容差（单位：元）。只用于吸收双精度乘法误差
    #: （约 1e-14 量级），不是"允许多涨半个百分点"的业务容差——原实现在比率
    #: 空间直接减 0.005，等于放大了 prev_close 倍，会把涨幅落在
    #: [limit-0.5%, limit) 的开盘价系统性误判为封板不可成交。
    PRICE_EPS = 1e-9

    #: ST/*ST 及"ST 状态未知"时的涨跌停幅度
    ST_LIMIT_PCT = 0.05

    #: 无法从证券代码推导时的兜底涨跌停幅度（主板默认）
    DEFAULT_LIMIT_PCT = 0.10

    #: 显式代码段表：(代码前缀元组, 涨跌停幅度, 板块名)，按顺序匹配、最长前缀优先。
    #: 900/200 沪深的 B 股必须显式列出为 10%——否则 900xxx 会被更早的北交所
    #: 判定吞掉，30% 阈值等于取消 B 股的涨跌停约束。
    BOARD_RULES = (
        (('688', '689'), 0.20, 'STAR'),        # 科创板（689 为 CDR 段）
        (('300', '301'), 0.20, 'CHINEXT'),     # 创业板（注册制前 10% 的日期规则尚未接入）
        (('900',), 0.10, 'SH_B'),              # 沪市 B 股
        (('200',), 0.10, 'SZ_B'),              # 深市 B 股
    )

    #: 无交易所后缀时的北交所号段兜底。不再使用 '4'/'8'/'9' 宽泛前缀：
    #: '9' 会误伤 900xxx 沪市 B 股，'8'/'4' 会误伤新三板/老三板代码。
    #: 920 为北交所新号段（如 920001.BJ），代码段会随时间新增，后缀判定更可靠。
    BJ_PREFIXES = ('83', '87', '88', '920')

    def __init__(self, lot_size: int = 100):
        self.lot_size = lot_size

    @staticmethod
    def resolve_limit_pct(ts_code: str = '', is_st: bool | None = None) -> float:
        """
        按证券代码与 ST 状态推导涨跌停幅度（唯一真源）。

        ST 状态为三态语义：
        - ``None``（默认，数据层未提供 ST 标识）→ 5%，按最严处理。
          未知时若按板块的 10%/20% 判定，ST 股开盘 +4.9% 会被当成完全可
          交易，在连续一字涨停行情里产生虚假成交、系统性虚增收益；
        - ``True`` → 5%（ST/*ST 真实幅度）；
        - ``False`` → 按板块规则：科创板 688/689 与创业板 300/301 → 20%、
          北交所 → 30%（优先 .BJ 后缀，无后缀按 83/87/88/920 号段兜底）、
          沪市 B 股 900xxx / 深市 B 股 200xxx 与其余主板 → 10%。

        注：ST 状态随戴帽/摘帽逐年变化，精确判定需要
        (code, start_date, end_date, is_st) 时间维表；当前数据层未提供，
        故调用方只能走 None 分支，保守按 5% 成交判定。
        """
        # 未知与明确 ST 同按 5%：两者对"是否可能已封板"的保守结论一致，
        # 差异体现在结果的 st_unknown 标记上（未知时 fill_confidence=low）
        if is_st is None or is_st:
            return ExecutionRules.ST_LIMIT_PCT

        ts_code = (ts_code or '').strip().upper()
        code = ts_code.split('.')[0]
        if not code:
            return ExecutionRules.DEFAULT_LIMIT_PCT

        # 北交所：交易所后缀最可靠（代码段会新增），无后缀时用显式号段兜底
        if ts_code.endswith('.BJ'):
            return 0.30
        if code.startswith(ExecutionRules.BJ_PREFIXES):
            return 0.30

        for prefixes, pct, _board in ExecutionRules.BOARD_RULES:
            if code.startswith(prefixes):
                return pct

        return ExecutionRules.DEFAULT_LIMIT_PCT

    def is_tradable(self, side: str, *, prev_close: float | None, open_price: float | None,
                    high: float | None, low: float | None, close: float | None,
                    volume: float | None, ts_code: str = '',
                    is_st: bool | None = None) -> bool:
        """
        指定交易方向在某一天是否可成交。

        - 停牌（成交量为 0 / NaN / inf）一律不可交易
        - 有开盘价时：开盘即涨停不可买、开盘即跌停不可卖
          （覆盖一字板 + 开盘封板后盘中打开两种情形）
        - 无开盘价时退化为 high ≈ low（相对容差）的一字板判断，
          此时只做 close 涨跌停判定（偏乐观），调用侧应确保 open 列存在
        - 首根 K 线没有前收盘价，只做停牌判断
        - is_st 默认 None 表示 ST 状态未知，按 5% 严格判定（见
          resolve_limit_pct），避免 ST 股在 10%/20% 阈值下产生虚假成交
        """
        # 缺陷 A 修复：NaN / inf 穿过停牌检查，显式拦截
        if volume is None or not math.isfinite(volume) or volume <= 0:
            return False

        if prev_close is None or prev_close <= 0:
            return True

        limit = self.resolve_limit_pct(ts_code, is_st)

        if open_price is not None and math.isfinite(open_price):
            # 价格空间比较：涨跌停价由前收盘价直接推出，不再在比率空间做减法。
            # 原写法 (open_pct >= limit - 0.005) 的容差被放大 prev_close 倍，
            # 3 元股等价于允许 1.5% 偏差、200 元股允许 0.25% 偏差，
            # 结果是把 [limit-0.5%, limit) 的正常开盘价误当成封板双向拒绝。
            if side == 'buy' and open_price >= prev_close * (1 + limit) - self.PRICE_EPS:
                return False
            if side == 'sell' and open_price <= prev_close * (1 - limit) + self.PRICE_EPS:
                return False
            return True

        # 缺陷 B 修复：复权后 high / low 可能相差 1e-16，改用相对容差
        # 缺陷 C 修复：open_price 缺失时只退化到此分支，偏乐观
        if high is not None and low is not None and close is not None:
            if abs(high - low) / prev_close < 1e-6:
                if side == 'buy' and close >= prev_close * (1 + limit) - self.PRICE_EPS:
                    return False
                if side == 'sell' and close <= prev_close * (1 - limit) + self.PRICE_EPS:
                    return False

        return True


class AccountBook:
    """
    账户账本：按标的拆分现金桶（组合等权分配），持仓、最新价与权益估值统一在此维护。

    单票回测只有一个现金桶，等价于原来的全局 current_capital。
    """

    def __init__(self, initial_capital: float, codes: List[str],
                 industry_map: Dict[str, str] | None = None):
        self.codes = list(codes)
        self.industry_map = dict(industry_map or {})
        per_code = initial_capital / len(self.codes) if self.codes else 0.0
        self.cash: Dict[str, float] = dict.fromkeys(self.codes, per_code)
        self.positions: Dict[str, int] = dict.fromkeys(self.codes, 0)
        self.last_prices: Dict[str, float] = {}

    @property
    def total_cash(self) -> float:
        return sum(self.cash.values())

    def mark(self, code: str, price: float | None) -> None:
        """更新盯市价（收盘后调用）。"""
        if price is not None and price > 0:
            self.last_prices[code] = float(price)

    def buy(self, code: str, price: float, shares: int, cost: float) -> None:
        """买入：现金扣除成交额与买方成本，持仓增加。"""
        self.cash[code] -= shares * price + cost
        self.positions[code] = self.positions.get(code, 0) + shares

    def sell(self, code: str, price: float, shares: int, cost: float) -> None:
        """卖出：所得净额叠加回该标的现金桶（不能覆盖买入后剩余现金）。"""
        self.cash[code] += shares * price - cost
        self.positions[code] = 0

    def total_equity(self) -> float:
        """权益 = 各桶现金之和 + 各持仓按最新价盯市。"""
        equity = self.total_cash
        for code, qty in self.positions.items():
            if qty > 0:
                equity += qty * self.last_prices.get(code, 0.0)
        return equity

    def snapshot(self, equity_curve: List[Dict[str, Any]]) -> RiskPortfolio:
        """构造风控用的组合快照。

        equity_curve 共享调用方的列表引用、不做复制：风控规则只切片读取尾部
        window（如 MaxDrawdown），快照对象在同一次订单审查结束即被丢弃。
        原实现在这里 list(equity_curve) 整体复制，每笔候选订单一次，
        10 年（T≈2400）× 日均 m 笔时累计复制 O(mT²) 个元素，是长周期
        组合回测的主要纯开销。
        """
        return RiskPortfolio(
            positions={code: qty for code, qty in self.positions.items() if qty > 0},
            last_prices=dict(self.last_prices),
            cash=self.total_cash,
            industry_map=dict(self.industry_map),
            equity_curve=equity_curve,
        )


class RiskGate:
    """风控闸门：唯一的 RiskOrder 构造与 gate() 调用入口。"""

    def __init__(self, risk_engine: RiskEngine | None, industry_map: Dict[str, str] | None = None):
        self.risk_engine = risk_engine
        self.industry_map = dict(industry_map or {})

    def check(self, *, ts_code: str, side: str, qty: int, price: float,
              trade_date: Any, book: AccountBook,
              equity_curve: List[Dict[str, Any]]) -> Dict[str, Any] | None:
        """
        审查一笔候选订单。

        Returns:
            None 表示放行；否则返回可直接写入 rejected_orders 的拒单记录。
        """
        if self.risk_engine is None:
            return None

        order = RiskOrder(
            ts_code=ts_code,
            side=side,
            qty=qty,
            price=price,
            industry=self.industry_map.get(ts_code, ''),
            trade_date=trade_date,
        )
        gate = self.risk_engine.gate([order], book.snapshot(equity_curve))
        if not gate.rejected:
            return None

        _, rule_name, reason = gate.rejected[0]
        return {
            'date': trade_date,
            'side': side,
            'ts_code': ts_code,
            'qty': qty,
            'price': price,
            'rule': rule_name,
            'reason': reason,
        }


class EventBacktestRunner:
    """
    通用事件循环：多标的日频回测的唯一撮合实现。

    输入 universe 必须已完成指标预计算（策略按列名读取 ma_* / macd / rsi 等）。
    """

    def __init__(self, cost_model: CostModel, performance_analyzer: PerformanceAnalyzer,
                 risk_engine: RiskEngine | None = None):
        self.cost_model = cost_model
        self.performance_analyzer = performance_analyzer
        self.risk_engine = risk_engine

    def run(self, universe: Dict[str, pl.DataFrame], strategies: Dict[str, Any],
            initial_capital: float = 1_000_000.0, lot_size: int = 100,
            industry_map: Dict[str, str] | None = None,
            result_meta: Dict[str, Any] | None = None,
            st_status: Dict[str, bool | None] | None = None) -> Dict[str, Any]:
        """
        执行回测并返回结果字典。

        结果固定包含：initial_capital / final_equity / total_return / trades /
        equity_curve / performance / risk_summary / rejected_orders /
        expired_orders / positions / slow_path_strategies / st_unknown。
        result_meta 里的键会合并进结果（如 strategy_name / strategy_names）。

        st_status 为 (标的名 → ST 三态) 映射：True=ST、False=明确非 ST、
        未出现在映射中=状态未知。未知标的按 ST 的 5% 保守判定涨跌停，
        并把逐笔 fill_confidence 降为 low——ST 股开盘 +4.9% 已被封板，
        若按 10%/20% 判定会放行虚假成交、系统性虚增收益。
        接入 (code, start_date, end_date, is_st) 时间维表后由调用方传此参数。

        universe 价格口径（双价格列契约）：
            - open/high/low/close 为指标与收益计算用价（DataFetcher hfq 出口
              即为后复权价）；
            - 若携带 raw_open / raw_close（hfq 出口自动保留的原始价），
              涨跌停判定一律使用原始价——交易所规则定义在原始价上，除权日
              因子跳变会使复权比值失真；两列必须成对出现；
            - 无 raw_* 列时视为原始价输入（如 TDX 本地数据），直接用主列判定。
        """
        if not universe:
            logger.error("回测数据为空")
            return {}

        codes = list(universe.keys())
        if not any(code in strategies for code in codes):
            logger.error("未设置策略")
            return {}

        prepared = {code: self._ensure_sorted(universe[code]) for code in codes}

        for code, df in prepared.items():
            if ('raw_open' in df.columns) != ('raw_close' in df.columns):
                raise ValueError(f"{code} 的 raw_open / raw_close 必须成对出现")

        # 一次性把各列批量导出为 Python list（to_list 将 null 转为 None，与
        # 原先 .row(named=True) 的取值语义完全一致），主循环只做数组下标取值
        # 与纯 Python dict 组装，避免逐 bar 调用 DataFrame.row() 反复跨越
        # PyO3 边界编组整行
        column_data: Dict[str, Dict[str, list]] = {
            code: {name: df[name].to_list() for name in df.columns}
            for code, df in prepared.items()
        }

        # 缺陷 C：open 列缺失时 is_tradable 退化为 high≈low 路径，
        # 判定偏乐观（遗漏"开盘涨停、盘中打开"等情形）。
        # 整次回测任一标的缺 open 列 → 标记 fill_confidence 为 low。
        _open_missing = any('open' not in cols for cols in column_data.values())
        if _open_missing:
            logger.warning(
                "部分标的缺 open 列，开盘涨停判定将退化为 high≈low 路径，"
                "成交假设偏乐观（fill_confidence=low）。"
                "缺失标的: {}",
                [c for c, cols in column_data.items() if 'open' not in cols],
            )

        # ST 三态：True=ST、False=明确非 ST、未提供=未知（按 5% 保守判定）。
        # 历史 ST 状态需 (code, start_date, end_date, is_st) 时间维表才能精确
        # 判定（戴帽/摘帽逐年变化，只取当前名称会在历史区间张冠李戴），
        # 当前数据层未提供，故默认全部走未知分支。
        st_status = dict(st_status or {})
        unknown_st_codes = [c for c in codes if st_status.get(c) is None]
        st_unknown = bool(unknown_st_codes)
        if st_unknown:
            logger.warning(
                "ST 状态未知的标的 {} 只（如 {}），涨跌停按 5% 保守判定，"
                "订单 fill_confidence=low；若沿用 10%/20% 会让 ST 股 +4.9% 开盘"
                "被放行成交而虚增收益。接入 ST 时间维表后传入 st_status 即可解除。",
                len(unknown_st_codes), unknown_st_codes[:5],
            )

        # 信号批量预生成：每个标的只调用一次向量化策略接口，主循环退化为
        # 数组下标取值，消除 N_days × N_symbols 次逐行策略调用与行 dict 组装。
        # 信号按 prepared[code] 的行序对齐（_ensure_sorted 保证日期升序），
        # 主循环里的 pos 即该信号在序列中的下标。未提供向量化接口的鸭子类型
        # 策略对象在此逐行适配，主循环保持单一查表路径。
        #
        # 降级路径的代价是一次回测 O(N_days × N_symbols) 次 Python 调用 + 行
        # dict 构造，相比向量化是数量级的差距（分钟级 → 小时级）。此处必须
        # 留痕：打 warning 并把策略名写进结果，避免调用方对慢速回测无感知。
        signal_columns: Dict[str, list] = {}
        slow_path_strategies: List[Dict[str, str]] = []
        for code in codes:
            strategy = strategies.get(code)
            if strategy is None:
                continue
            vec = getattr(strategy, 'generate_signals_vectorized', None)
            # BaseStrategy 的默认实现内部就是逐行循环调 generate_signal，
            # 性能与降级路径同级，不能因为方法存在就当成向量化快路径。
            is_fallback = vec is not None and getattr(
                getattr(vec, '__func__', vec), 'is_fallback_impl', False)
            if vec is not None and not is_fallback:
                signal_columns[code] = vec(prepared[code]).to_list()
            else:
                strategy_name = getattr(strategy, 'name', None) or type(strategy).__name__
                cols = column_data[code]
                height = len(next(iter(cols.values()))) if cols else 0
                rows = height * len(cols)
                slow_path_strategies.append({'ts_code': code, 'strategy': strategy_name})
                logger.warning(
                    "策略 {} ({}) 未覆写 generate_signals_vectorized，"
                    "信号生成退化为逐 bar Python 调用（{} 行 × {} 列 = {} 次取值），"
                    "回测耗时为向量化路径的数量级之上（slow_path_strategies）",
                    strategy_name, code, height, len(cols), rows,
                )
                if vec is not None:
                    # BaseStrategy 的逐行兜底实现，语义等价于下方的鸭子类型适配
                    signal_columns[code] = vec(prepared[code]).to_list()
                else:
                    signal_columns[code] = [
                        strategy.generate_signal(
                            {name: col[i] for name, col in cols.items()}, i
                        )
                        for i in range(height)
                    ]

        # 一次性建立 date -> 行号索引（用 dict(zip) 替代手动 enumerate 循环），
        # 同时建反向索引 date -> [codes]，主循环按日期直查活跃标的，消除
        # 笛卡尔遍历下大量 date_positions[code].get(date) -> None -> continue
        # 的无效分支（标的上市日期分散时占外层迭代 40~50%）。
        date_positions: Dict[str, Dict[Any, int]] = {}
        date_codes: Dict[Any, List[str]] = {}
        sorted_dates: List[Any] = []
        for code, cols in column_data.items():
            dates = cols['date']
            positions = dict(zip(dates, range(len(dates))))
            date_positions[code] = positions
            for d in positions:
                bucket = date_codes.setdefault(d, [])
                bucket.append(code)
        sorted_dates = sorted(date_codes.keys())

        rules = ExecutionRules(lot_size=lot_size)
        # 现金桶只分配给配置了策略的标的：universe 里加载了但没配策略的"哑标的"
        # 若参与 initial_capital / len(codes) 的等额切分，其份额全程闲置，
        # 冻结比例恰等于无策略标的占比（20 只里只有 5 只配策略 → 75% 本金不动），
        # 净值曲线被压成近水平线、最大回撤被压低，结果会被误读为"策略很稳"。
        active_codes = [c for c in codes if c in strategies]
        book = AccountBook(initial_capital, active_codes, industry_map)
        gate = RiskGate(self.risk_engine, industry_map)

        pending: Dict[str, str | None] = dict.fromkeys(codes)
        prev_close: Dict[str, float | None] = dict.fromkeys(codes)
        prev_raw_close: Dict[str, float | None] = dict.fromkeys(codes)

        trades: List[Dict[str, Any]] = []
        rejected_orders: List[Dict[str, Any]] = []
        expired_orders: List[Dict[str, Any]] = []
        equity_curve: List[Dict[str, Any]] = []

        for date in sorted_dates:
            for code in date_codes[date]:
                pos = date_positions[code][date]
                cols = column_data[code]
                close_price = cols['close'][pos]
                # 列不存在时回退默认值，语义同原 row.get(name, default)；
                # 列存在但值为 None（null）时透传 None，不回退
                open_col = cols.get('open')
                open_price = open_col[pos] if open_col is not None else close_price
                high_col = cols.get('high')
                high = high_col[pos] if high_col is not None else None
                low_col = cols.get('low')
                low = low_col[pos] if low_col is not None else None
                volume_col = cols.get('volume')
                volume = volume_col[pos] if volume_col is not None else None
                raw_open_col = cols.get('raw_open')
                raw_open = raw_open_col[pos] if raw_open_col is not None else None
                raw_close_col = cols.get('raw_close')
                raw_close = raw_close_col[pos] if raw_close_col is not None else None

                self._execute_pending(
                    code=code, date=date, pending=pending, book=book, gate=gate,
                    rules=rules, cost_model=self.cost_model, trades=trades,
                    rejected_orders=rejected_orders, expired_orders=expired_orders,
                    equity_curve=equity_curve,
                    lot_size=lot_size,
                    prev_close=prev_close[code], open_price=open_price,
                    high=high, low=low, close=close_price, volume=volume,
                    open_raw=raw_open, prev_close_raw=prev_raw_close[code],
                    close_raw=raw_close,
                    is_st=st_status.get(code),
                )

                # 策略基于当日数据生成信号，延迟到该标的下一个交易日执行；
                # 信号已在主循环前按行序批量生成，此处仅按下标查表
                signals = signal_columns.get(code)
                if signals is not None:
                    signal = signals[pos]
                    if signal in ('buy', 'sell'):
                        # P0-4：pending 残留挂单被新信号覆盖时必须记账，
                        # 否则原始信号彻底消失，trades 分母不可对账。
                        # 场景：停牌日 _execute_pending 不执行，pending 残留 →
                        # 下一有信号日直接覆写，无任何日志。
                        old = pending.get(code)
                        if old is not None and old != signal:
                            expired_orders.append({
                                'date': date, 'side': old, 'ts_code': code,
                                'reason': 'overwritten', 'qty': 0,
                            })
                        pending[code] = signal

                # close 缺失 / 非有限 / ≤0 时，挂单已在 _execute_pending 里过期；
                # 此处不更新 prev_close / book.mark，保留上一个有效值
                if close_price is None or not math.isfinite(close_price) or close_price <= 0:
                    continue
                prev_close[code] = close_price
                prev_raw_close[code] = raw_close if raw_close is not None else close_price
                book.mark(code, close_price)

            equity_curve.append({'date': date, 'equity': book.total_equity()})

        final_equity = equity_curve[-1]['equity'] if equity_curve else initial_capital
        total_return = (final_equity - initial_capital) / initial_capital * 100

        performance = self.performance_analyzer.analyze(equity_curve, trades)

        risk_summary = None
        if self.risk_engine is not None:
            risk_summary = {
                'rules': [r.name for r in self.risk_engine.rules],
                'total_rejected': len(rejected_orders),
                'reject_detail': [
                    f"[{r['date']}] {r['side']} {r['ts_code']} qty={r['qty']} → {r['rule']}: {r['reason']}"
                    for r in rejected_orders
                ],
            }

        result: Dict[str, Any] = {
            'initial_capital': initial_capital,
            'final_equity': final_equity,
            'total_return': total_return,
            'trades': trades,
            'equity_curve': equity_curve,
            'performance': performance,
            'risk_summary': risk_summary,
            'rejected_orders': rejected_orders,
            'expired_orders': expired_orders,
            # 最终持仓直接取自 AccountBook 账本（唯一真源），
            # 不在引擎侧用 trades 反推，避免账本外再维护一份持仓状态
            'positions': dict(book.positions),
            # 慢速路径标记：非空表示这些策略未实现 generate_signals_vectorized，
            # 信号走了逐 bar Python 调用；空列表表示全部走向量化路径
            'slow_path_strategies': slow_path_strategies,
            # 缺陷 C：整次回测任一标的缺 open 列 → 开盘涨停判定退化，
            # 成交假设偏乐观；ST 状态未知时同样整体偏乐观/保守不可全信
            'fill_confidence': 'low' if (_open_missing or st_unknown) else 'high',
            # ST 状态是否未知：True 表示本次回测按 5% 保守判定涨跌停，
            # 逐笔 fill_confidence 也相应为 low，调用方应据此解读成交假设
            'st_unknown': st_unknown,
        }
        if result_meta:
            result.update(result_meta)

        logger.info(
            f"回测完成: 总收益率 = {total_return:.2f}%"
            + (f" | 风控拒单 {len(rejected_orders)} 笔" if risk_summary else "")
            + (f" | 挂单作废 {len(expired_orders)} 笔" if expired_orders else "")
        )
        return result

    # ------------------------------------------------------------------
    # 撮合
    # ------------------------------------------------------------------

    def _execute_pending(self, *, code: str, date: Any, pending: Dict[str, str | None],
                         book: AccountBook, gate: RiskGate, rules: ExecutionRules,
                         cost_model: CostModel, trades: List[Dict[str, Any]],
                         rejected_orders: List[Dict[str, Any]],
                         expired_orders: List[Dict[str, Any]],
                         equity_curve: List[Dict[str, Any]], lot_size: int,
                         prev_close: float | None, open_price: float | None,
                         high: float | None, low: float | None,
                         close: float | None, volume: float | None,
                         open_raw: float | None = None,
                         prev_close_raw: float | None = None,
                         close_raw: float | None = None,
                         is_st: bool | None = None) -> None:
        """执行该标的的挂单。

        订单生命周期语义（显式状态机，杜绝静默丢单）：
            - 标的停牌无数据行时不进入本函数，挂单顺延至下一交易日；
            - 进入本函数即消费挂单，当日有效：成交进 trades、被风控拦截进
              rejected_orders、其余不可成交情形一律作废并记入 expired_orders
              （already_holding / no_position / not_tradable / price_missing /
              insufficient_cash），不会残留到下一交易日。

        is_st 为 None 表示 ST 状态未知：涨跌停按 5% 严格判定，且该笔订单的
        fill_confidence 标记为 low，提示成交假设可能偏保守/不可全信。
        """
        side = pending.pop(code, None)
        if side is None:
            return

        position = book.positions.get(code, 0)
        st_unknown = is_st is None
        order_confidence = 'low' if st_unknown else 'high'

        def _expire(reason: str, qty: int = 0) -> None:
            expired_orders.append({
                'date': date, 'side': side, 'ts_code': code,
                'reason': reason, 'qty': qty,
                'fill_confidence': order_confidence,
            })

        # 持仓前置条件不满足：已持仓的买入、无持仓的卖出
        if side == 'buy' and position > 0:
            _expire('already_holding')
            return
        if side == 'sell' and position == 0:
            _expire('no_position')
            return

        # close 缺失 = 无有效行情，挂单作废（主循环已 continue 跳过整行，
        # 此处防御性守卫，确保函数签名 close=None 不会漏进来）
        if close is None or not math.isfinite(close) or close <= 0:
            _expire('price_missing')
            return

        # 涨跌停 / 停牌（零成交量）当日不可按该方向成交。
        # 交易所规则定义在原始价上：数据携带 raw_* 列（hfq 复权输入）时
        # 必须用原始价判定，除权日因子跳变会让复权比值失真（误触发/误放行）；
        # high == low 的一字板等式判断在线性缩放下不变，可直接透传。
        check_open = open_raw if open_raw is not None else open_price
        check_prev = prev_close_raw if prev_close_raw is not None else prev_close
        check_close = close_raw if close_raw is not None else close
        if not rules.is_tradable(side, prev_close=check_prev, open_price=check_open,
                                 high=high, low=low, close=check_close, volume=volume,
                                 ts_code=code, is_st=is_st):
            _expire('not_tradable')
            return

        # P0-2 修复：开盘价是集合竞价成交价。open_price 为 None（列存在但值缺失，
        # 如停牌复牌日、除权日）时，不能用 close 伪造成交价——回测不应发明价格。
        # 列整体缺失时 open_price 已在主循环回填为 close_price + fill_confidence=low，
        # 此处不会走到 None 分支。
        if open_price is None or not math.isfinite(open_price) or open_price <= 0:
            _expire('price_missing')
            return
        exec_price = open_price

        if side == 'buy':
            available = book.cash.get(code, 0.0)
            cost_rate = cost_model.get_buy_cost_rate()
            affordable = available / (exec_price * (1 + cost_rate))
            shares = int(affordable // lot_size) * lot_size
            # 费率估算不含 min_commission 下限，小单实际成本可能超估算：
            # 按实际成本逐手回退，而不是整笔静默作废
            buy_cost = 0.0
            total_pay = 0.0
            while shares > 0:
                buy_cost = cost_model.calculate_buy_cost(shares, exec_price)
                total_pay = shares * exec_price + buy_cost
                if total_pay <= available:
                    break
                shares -= lot_size
            if shares == 0:
                _expire('insufficient_cash')
                return
            rejection = gate.check(
                ts_code=code, side='buy', qty=shares, price=exec_price,
                trade_date=date, book=book, equity_curve=equity_curve,
            )
            if rejection is not None:
                rejected_orders.append(rejection)
                return
            book.buy(code, exec_price, shares, buy_cost)
            trades.append({
                'date': date,
                'stock_code': code,
                'signal': 'buy',
                'price': exec_price,
                'shares': shares,
                'capital': book.cash[code],
                'position': book.positions[code],
                'cost': buy_cost,
                'fill_confidence': order_confidence,
            })
            return

        # side == 'sell'（持仓前置条件已在上方校验）
        shares = book.positions[code]
        sell_cost = cost_model.calculate_sell_cost(shares, exec_price)
        rejection = gate.check(
            ts_code=code, side='sell', qty=shares, price=exec_price,
            trade_date=date, book=book, equity_curve=equity_curve,
        )
        if rejection is not None:
            rejected_orders.append(rejection)
            return
        book.sell(code, exec_price, shares, sell_cost)
        trades.append({
            'date': date,
            'stock_code': code,
            'signal': 'sell',
            'price': exec_price,
            'shares': shares,
            'capital': book.cash[code],
            'position': 0,
            'cost': sell_cost,
            'fill_confidence': order_confidence,
        })

    @staticmethod
    def _ensure_sorted(df: pl.DataFrame) -> pl.DataFrame:
        """按日期升序，保证日期索引与执行顺序一致。"""
        if 'date' in df.columns and not df['date'].is_sorted():
            return df.sort('date')
        return df
