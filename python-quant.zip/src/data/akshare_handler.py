#!/usr/bin/env python3

"""
AkShare数据处理器

对 akshare 上游的全部依赖（端点名、字段名、别名）集中在
src/data/sources/akshare_schema.py；本模块只做编排与入库，
不再 import akshare、不再出现上游列名。
"""

from datetime import datetime
from typing import List

import polars as pl
from loguru import logger

from src.data.sources import akshare_schema as schema
from src.data.sources.base import DataSourceBase
from src.utils.code_converter import to_symbol, to_ts_code
from src.utils.exception_handler import handle_exception_with_retry
from src.utils.exceptions import DataSourceConnectionError


class AkShareHandler(DataSourceBase):
    """
    AkShare数据处理器，负责从AkShare获取数据并存储到数据库

    继承 DataSourceBase 获得统一接口（is_available / 15+ update_* 默认 stubs）。
    实际数据获取由 DataFetcher._get_data_from_sources 按 handler 名硬编码
    调用对应方法（get_stock_data / get_index_data）。

    事务契约：
        1. 单表批量写入可按标的/批次 commit（checkpoint），用于长任务断点续传；
        2. 同一方法内出现跨表写入时，必须收敛到单一 commit 边界
           （优先 db_manager.transaction()），禁止跨表多次提交；
        3. 跨阶段的流水线（如行情同步与复权因子计算）不合并为同一事务，
           避免长事务持锁，一致性由各阶段的原子写入 + 事后校验保证。
    """

    def __init__(self, config, db_manager):
        """
        初始化AkShare数据处理器

        Args:
            config: 配置对象
            db_manager: 数据库管理器实例
        """
        self.config = config
        self.db_manager = db_manager
        self.name = "AkShareHandler"
        self.available = True
        self._factor_warning_logged = False
        self.session = None

        # 离线模式支持
        if db_manager:
            try:
                self.session = db_manager.get_session()
            except (ConnectionError, TimeoutError, OSError) as e:
                logger.warning(f"数据库会话获取失败（离线模式下正常）: {e}")
                self.session = None
        else:
            logger.info("AkShareHandler在离线模式下初始化")

    def update_stock_basic(self):
        """
        更新股票基本信息
        """
        try:
            logger.info("开始从AkShare获取股票基本信息")

            # 使用AkShare获取股票基本信息（上游契约见 akshare_schema.STOCK_BASIC）
            stock_basic_df = schema.resolve(
                schema.fetch_spec(schema.STOCK_BASIC), schema.STOCK_BASIC)

            if stock_basic_df.is_empty():
                logger.warning("从AkShare获取的股票基本信息为空")
                return

            logger.info(f"从AkShare获取到{stock_basic_df.height}条股票基本信息")

            # 离线模式下，只获取数据不存储
            if not self.session:
                logger.info("离线模式下，跳过股票基本信息存储")
                return stock_basic_df  # 离线模式下返回Polars DataFrame

            # 数据清洗和标准化
            from src.database.models.stock import StockBasic

            # 遍历数据，进行清洗和存储
            for row in stock_basic_df.iter_rows(named=True):
                try:
                    # 提取股票代码和名称
                    symbol = row['symbol']
                    name = row['name']

                    # 构建完整的ts_code（统一市场推断，含北交所 4/8/92 开头）
                    ts_code = to_ts_code(symbol)

                    # 查询股票是否已存在
                    stock = self.session.query(StockBasic).filter_by(ts_code=ts_code).first()

                    if stock:
                        # 更新现有股票信息
                        stock.name = name[:45] if len(name) > 45 else name
                        stock.symbol = symbol[:9] if len(symbol) > 9 else symbol
                    else:
                        # 创建新股票信息
                        stock = StockBasic(
                            ts_code=ts_code,
                            symbol=symbol[:9] if len(symbol) > 9 else symbol,
                            name=name[:45] if len(name) > 45 else name
                        )
                        self.session.add(stock)

                except (ConnectionError, TimeoutError, OSError) as row_e:
                    logger.exception(f"处理股票基本信息失败: {row_e}")
                    continue

            # 提交事务
            self.session.commit()
            logger.info("股票基本信息更新完成")
            return stock_basic_df  # 返回Polars DataFrame

        except (ConnectionError, TimeoutError, OSError) as e:
            if self.session:
                self.session.rollback()
            logger.exception(f"从AkShare获取股票基本信息失败: {e}")
            raise

    def update_market_breadth(self, trade_date: str = None):
        """
        更新市场涨跌家数数据

        Args:
            trade_date: 交易日期，格式YYYYMMDD，默认获取最新数据
        """
        try:
            logger.info("开始获取市场涨跌家数数据")

            # 使用AkShare获取A股实时行情数据（契约见 akshare_schema.MARKET_BREADTH）
            df = schema.resolve(
                schema.fetch_spec(schema.MARKET_BREADTH), schema.MARKET_BREADTH)

            if df.is_empty():
                logger.warning("获取市场涨跌家数数据为空")
                return None

            # 统计涨跌家数
            up_count = df.filter(pl.col('pct_chg') > 0).height
            down_count = df.filter(pl.col('pct_chg') < 0).height
            flat_count = df.filter(pl.col('pct_chg') == 0).height
            total_count = df.height

            # 计算涨跌比例
            up_rate = (up_count / total_count * 100) if total_count > 0 else 0
            down_rate = (down_count / total_count * 100) if total_count > 0 else 0

            logger.info(f"市场涨跌家数: 上涨={up_count}, 下跌={down_count}, 平盘={flat_count}, 总计={total_count}")

            # 转换日期格式
            from datetime import datetime
            if trade_date:
                trade_date_obj = datetime.strptime(trade_date, "%Y%m%d").date()
            else:
                trade_date_obj = datetime.now().date()

            # 离线模式下返回结果
            if not self.session:
                return {
                    'trade_date': trade_date_obj,
                    'up_count': up_count,
                    'down_count': down_count,
                    'flat_count': flat_count,
                    'total_count': total_count,
                    'up_rate': up_rate,
                    'down_rate': down_rate
                }

            # 存储到数据库
            from src.database.models.stock import MarketBreadth

            # 查询是否已存在
            existing = self.session.query(MarketBreadth).filter_by(trade_date=trade_date_obj).first()

            if existing:
                existing.up_count = up_count
                existing.down_count = down_count
                existing.flat_count = flat_count
                existing.total_count = total_count
                existing.up_rate = up_rate
                existing.down_rate = down_rate
                logger.info(f"更新市场涨跌家数数据: {trade_date_obj}")
            else:
                market_breadth = MarketBreadth(
                    trade_date=trade_date_obj,
                    up_count=up_count,
                    down_count=down_count,
                    flat_count=flat_count,
                    total_count=total_count,
                    up_rate=up_rate,
                    down_rate=down_rate
                )
                self.session.add(market_breadth)
                logger.info(f"新增市场涨跌家数数据: {trade_date_obj}")

            self.session.commit()
            return {
                'trade_date': trade_date_obj,
                'up_count': up_count,
                'down_count': down_count,
                'flat_count': flat_count,
                'total_count': total_count,
                'up_rate': up_rate,
                'down_rate': down_rate
            }

        except (ConnectionError, TimeoutError, OSError) as e:
            if self.session:
                self.session.rollback()
            logger.exception(f"获取市场涨跌家数数据失败: {e}")
            raise

    def update_stock_daily(self, ts_codes: List[str] = None, start_date: str = None, end_date: str = None):
        """
        更新股票日线数据

        Args:
            ts_codes: 股票代码列表，None表示更新所有股票
            start_date: 开始日期，格式：YYYYMMDD
            end_date: 结束日期，格式：YYYYMMDD

        Returns:
            dict: 股票代码到日线数据的映射（离线模式下）
        """
        try:
            # 离线模式下的默认股票代码列表
            default_ts_codes = ["600000.SH", "000001.SZ", "300001.SZ"]

            # 如果没有指定股票代码，从数据库获取所有股票代码
            if not ts_codes:
                if self.session:
                    from src.database.models.stock import StockBasic
                    stock_basics = self.session.query(StockBasic.ts_code).all()
                    ts_codes = [sb.ts_code for sb in stock_basics]
                else:
                    # 离线模式下使用默认股票代码
                    ts_codes = default_ts_codes
                    logger.info(f"离线模式下，使用默认股票代码列表: {ts_codes}")

            if not ts_codes:
                logger.warning("没有需要更新的股票代码")
                return

            # 如果没有指定日期，默认更新最近30天的数据
            if not end_date:
                end_date = datetime.now().strftime("%Y%m%d")
            if not start_date:
                # 默认更新最近30天的数据
                start_date = (datetime.now() - datetime.timedelta(days=30)).strftime("%Y%m%d")

            logger.info(f"开始更新{len(ts_codes)}只股票的日线数据，时间范围: {start_date} 至 {end_date}")

            # 存储结果（离线模式下返回）
            result = {}

            # 遍历股票代码，获取日线数据
            for ts_code in ts_codes:
                try:
                    logger.info(f"正在获取{ts_code}的日线数据")

                    # 使用AkShare获取股票日线数据（契约见 akshare_schema.STOCK_HIST）
                    stock_daily_df = schema.resolve(
                        schema.fetch_spec(
                            schema.STOCK_HIST,
                            symbol=to_symbol(ts_code),  # AkShare使用数字代码
                            period="daily",
                            start_date=start_date,
                            end_date=end_date,
                            adjust="",  # 不复权：写库统一存原始价，复权由查询侧 DataFetcher 按因子计算
                        ),
                        schema.STOCK_HIST,
                    )

                    if stock_daily_df.is_empty():
                        logger.warning(f"{ts_code}在{start_date}至{end_date}期间没有日线数据")
                        continue

                    logger.info(f"获取到{ts_code}的{stock_daily_df.height}条日线数据")

                    # 离线模式下，只获取数据不存储
                    if not self.session:
                        result[ts_code] = stock_daily_df
                        logger.info(f"离线模式下，获取{ts_code}的日线数据完成")
                        continue

                    # 数据清洗和标准化
                    from src.database.models.stock import StockDaily
                    from src.database.upsert import upsert_rows

                    # 遍历数据，转换为待写入行（不合格行跳过）
                    daily_rows = []
                    for row in stock_daily_df.iter_rows(named=True):
                        try:
                            daily_rows.append({
                                'ts_code': ts_code,
                                'trade_date': datetime.strptime(row['date'], "%Y-%m-%d").date(),
                                'open': row['open'],
                                'high': row['high'],
                                'low': row['low'],
                                'close': row['close'],
                                'pre_close': row['pre_close'],
                                'change': row['change'],
                                'pct_chg': row['pct_chg'],
                                'vol': row['volume'],
                                'amount': row['amount'],
                            })
                        except (ConnectionError, TimeoutError, OSError) as row_e:
                            logger.exception(f"处理股票日线数据失败: {row_e}")
                            continue

                    # 批量查重后写入（已存在则更新，不存在则新增）
                    upsert_rows(
                        self.session, StockDaily, daily_rows,
                        key_fields=('ts_code', 'trade_date'),
                        value_fields=('open', 'high', 'low', 'close', 'pre_close',
                                      'change', 'pct_chg', 'vol', 'amount'),
                    )

                    # 每只股票提交一次事务
                    self.session.commit()
                    logger.info(f"{ts_code}的日线数据更新完成")

                except (ConnectionError, TimeoutError, OSError) as e:
                    if self.session:
                        self.session.rollback()
                    logger.exception(f"获取{ts_code}的日线数据失败: {e}")
                    continue

            # 离线模式下返回结果
            if not self.session and result:
                return result

        except (ConnectionError, TimeoutError, OSError) as e:
            if self.session:
                self.session.rollback()
            logger.exception(f"更新股票日线数据失败: {e}")
            raise

    def update_index_basic(self):
        """
        更新指数基本信息
        """
        try:
            logger.info("开始从AkShare获取指数基本信息")

            # 使用AkShare获取指数基本信息（契约见 akshare_schema.INDEX_BASIC）
            index_basic_df = schema.resolve(
                schema.fetch_spec(schema.INDEX_BASIC), schema.INDEX_BASIC)

            if index_basic_df.is_empty():
                logger.warning("从AkShare获取的指数基本信息为空")
                return

            logger.info(f"从AkShare获取到{index_basic_df.height}条指数基本信息")

            # 离线模式下，只获取数据不存储
            if not self.session:
                logger.info("离线模式下，跳过指数基本信息存储")
                return index_basic_df

            # 数据清洗和标准化
            from src.database.models.index import IndexBasic

            # 遍历数据，进行清洗和存储
            for row in index_basic_df.iter_rows(named=True):
                try:
                    # 提取指数代码和名称
                    ts_code = row['ts_code']
                    name = row['name']

                    # 查询指数是否已存在
                    index_basic = self.session.query(IndexBasic).filter_by(ts_code=ts_code).first()

                    if index_basic:
                        # 更新现有指数信息
                        index_basic.name = name
                    else:
                        # 创建新指数信息
                        index_basic = IndexBasic(
                            ts_code=ts_code,
                            name=name
                        )
                        self.session.add(index_basic)

                except (ConnectionError, TimeoutError, OSError) as row_e:
                    logger.exception(f"处理指数基本信息失败: {row_e}")
                    continue

            # 提交事务
            self.session.commit()
            logger.info("指数基本信息更新完成")
            return index_basic_df

        except (ConnectionError, TimeoutError, OSError) as e:
            if self.session:
                self.session.rollback()
            logger.exception(f"从AkShare获取指数基本信息失败: {e}")
            raise

    def update_index_daily(self, ts_codes: List[str] = None, start_date: str = None, end_date: str = None):
        """
        更新指数日线数据

        Args:
            ts_codes: 指数代码列表，None表示更新所有指数
            start_date: 开始日期，格式：YYYYMMDD
            end_date: 结束日期，格式：YYYYMMDD

        Returns:
            dict: 指数代码到日线数据的映射（离线模式下）
        """
        try:
            # 离线模式下的默认指数代码列表（使用带前缀的格式）
            default_ts_codes = ["sh000001", "sz399001", "sz399006"]

            # 如果没有指定指数代码，从数据库获取所有指数代码
            if not ts_codes:
                if self.session:
                    from src.database.models.index import IndexBasic
                    index_basics = self.session.query(IndexBasic.ts_code).all()
                    ts_codes = [ib.ts_code for ib in index_basics]
                else:
                    # 离线模式下使用默认指数代码
                    ts_codes = default_ts_codes
                    logger.info(f"离线模式下，使用默认指数代码列表: {ts_codes}")

            if not ts_codes:
                logger.warning("没有需要更新的指数代码")
                return

            logger.info(f"开始更新{len(ts_codes)}个指数的日线数据")

            # 存储结果（离线模式下返回）
            result = {}

            # 遍历指数代码，获取日线数据
            for ts_code in ts_codes:
                try:
                    logger.info(f"正在获取{ts_code}的日线数据")

                    # 使用AkShare获取指数日线数据（契约见 akshare_schema.INDEX_DAILY）
                    index_daily_df = schema.resolve(
                        schema.fetch_spec(schema.INDEX_DAILY, symbol=ts_code),
                        schema.INDEX_DAILY,
                    )

                    if index_daily_df.is_empty():
                        logger.warning(f"{ts_code}没有日线数据")
                        continue

                    logger.info(f"获取到{ts_code}的{index_daily_df.height}条日线数据")

                    # 离线模式下，只获取数据不存储
                    if not self.session:
                        result[ts_code] = index_daily_df
                        logger.info(f"离线模式下，获取{ts_code}的日线数据完成")
                        continue

                    # 数据清洗和标准化
                    from src.database.models.index import IndexDaily
                    from src.database.upsert import upsert_rows

                    # 遍历数据，转换为待写入行（不合格行跳过）
                    daily_rows = []
                    for row in index_daily_df.iter_rows(named=True):
                        try:
                            daily_rows.append({
                                'ts_code': ts_code,
                                'trade_date': datetime.strptime(row['date'], "%Y-%m-%d").date(),
                                'open': row['open'],
                                'high': row['high'],
                                'low': row['low'],
                                'close': row['close'],
                                'vol': row['volume'],
                            })
                        except (ConnectionError, TimeoutError, OSError) as row_e:
                            logger.exception(f"处理指数日线数据失败: {row_e}")
                            continue

                    # 批量查重后写入（已存在则更新，不存在则新增）
                    upsert_rows(
                        self.session, IndexDaily, daily_rows,
                        key_fields=('ts_code', 'trade_date'),
                        value_fields=('open', 'high', 'low', 'close', 'vol'),
                        create_defaults={
                            'pre_close': 0.0,  # stock_zh_index_daily 不提供昨收价
                            'change': 0.0,  # 不提供涨跌额
                            'pct_chg': 0.0,  # 不提供涨跌幅
                            'amount': 0.0,  # 不提供成交额
                        },
                    )

                    # 每个指数提交一次事务
                    self.session.commit()
                    logger.info(f"{ts_code}的日线数据更新完成")

                except (ConnectionError, TimeoutError, OSError) as e:
                    if self.session:
                        self.session.rollback()
                    logger.exception(f"获取{ts_code}的日线数据失败: {e}")
                    continue

            # 离线模式下返回结果
            if not self.session and result:
                return result

        except (ConnectionError, TimeoutError, OSError) as e:
            if self.session:
                self.session.rollback()
            logger.exception(f"更新指数日线数据失败: {e}")
            raise

    def _save_dividend_rows(self, ts_code: str, rows: List[dict]):
        """
        分红配股数据入库（双键去重）

        匹配顺序：
            1. 有除权除息日：按 ts_code + ex_date 匹配
            2. 未命中且有报告期年度：匹配同年度 ex_date 为空的占位记录并回填 ex_date
            3. 无除权除息日：匹配同年度已有记录，避免同一年度重复插入
            4. 仍未命中：新增记录

        一次性预加载该股票全部已有记录，避免原实现逐行查询；
        更新时不会用缺失的 ex_date 覆盖已有日期。

        Args:
            ts_code: 标准股票代码
            rows: 已清洗的分红行字典列表

        Returns:
            Tuple[int, int]: (新增条数, 更新条数)
        """
        if not rows:
            return 0, 0

        from src.database.models.stock import StockDividend

        existing = self.session.query(StockDividend).filter_by(ts_code=ts_code).all()
        by_ex_date = {d.ex_date: d for d in existing if d.ex_date}

        # 同年度可能有多条，占位记录（ex_date 为空）取 id 最大的一条
        placeholders = {}
        # 同年度全部记录（含已有 ex_date 的），仅在本次缺 ex_date 时用于去重
        by_year = {}
        for item in existing:
            if not item.dividend_year:
                continue
            current = by_year.get(item.dividend_year)
            if current is None or (item.id or 0) > (current.id or 0):
                by_year[item.dividend_year] = item
            if not item.ex_date:
                current = placeholders.get(item.dividend_year)
                if current is None or (item.id or 0) > (current.id or 0):
                    placeholders[item.dividend_year] = item

        inserted = 0
        updated = 0

        for row in rows:
            target = None
            if row['ex_date']:
                target = by_ex_date.get(row['ex_date'])
                if target is None and row['dividend_year']:
                    # 用实施公告的 ex_date 回填早前的占位记录
                    target = placeholders.get(row['dividend_year'])
            elif row['dividend_year']:
                target = by_year.get(row['dividend_year'])

            values = {
                'report_date': row['report_date'],
                'record_date': row['record_date'],
                'pay_date': row['pay_date'],
                'cash_div': row['cash_div'],
                'share_div': row['share_div'],
                'total_div': row['total_div'],
                'rights_issue_price': row['rights_issue_price'],
                'rights_issue_ratio': row['rights_issue_ratio'],
            }
            if row['ex_date']:
                # 仅在本次确实带除权除息日时写入，避免缺失值覆盖已有日期
                values['ex_date'] = row['ex_date']

            if target is None:
                target = StockDividend(
                    ts_code=ts_code,
                    symbol=row['symbol'],
                    name=row['name'],
                    dividend_year=row['dividend_year'],
                    **values,
                )
                self.session.add(target)
                inserted += 1
            else:
                for field, value in values.items():
                    setattr(target, field, value)
                updated += 1

            # 同步索引，保证同一批内后续行能命中刚新增或刚回填的记录
            if target.ex_date:
                by_ex_date[target.ex_date] = target
                if placeholders.get(target.dividend_year) is target:
                    # 占位记录已回填 ex_date，不再作为占位参与后续回合
                    placeholders.pop(target.dividend_year)
            if target.dividend_year:
                by_year[target.dividend_year] = target

        return inserted, updated

    def update_stock_dividend(self, ts_codes: List[str] = None):
        """
        更新股票分红配股数据

        Args:
            ts_codes: 股票代码列表，None表示更新所有股票

        Returns:
            dict: 股票代码到分红数据的映射（离线模式下）
        """
        try:
            # 离线模式下的默认股票代码列表
            default_ts_codes = ["600000.SH", "000001.SZ", "300001.SZ"]

            # 如果没有指定股票代码，从数据库获取所有股票代码
            if not ts_codes:
                if self.session:
                    from src.database.models.stock import StockBasic
                    stock_basics = self.session.query(StockBasic.ts_code).all()
                    ts_codes = [sb.ts_code for sb in stock_basics]
                else:
                    # 离线模式下使用默认股票代码
                    ts_codes = default_ts_codes
                    logger.info(f"离线模式下，使用默认股票代码列表: {ts_codes}")

            if not ts_codes:
                logger.warning("没有需要更新的股票代码")
                return

            logger.info(f"开始更新{len(ts_codes)}只股票的分红配股数据")

            # 存储结果（离线模式下返回）
            result = {}

            # 遍历股票代码，获取分红配股数据
            for ts_code in ts_codes:
                try:
                    logger.info(f"正在获取{ts_code}的分红配股数据")

                    symbol = to_symbol(ts_code)

                    # 使用AkShare获取股票分红数据（契约见 akshare_schema.DIVIDEND）
                    # 接口: stock_fhps_detail_em - 获取历史分红数据(东方财富)
                    try:
                        dividend_df = schema.fetch_spec(schema.DIVIDEND, symbol=symbol)
                    except TypeError as e:
                        logger.warning(f"{ts_code}的分红配股数据获取失败，发生类型错误: {e}")
                        continue
                    except schema.AkShareContractError as e:
                        logger.error(f"{ts_code}的分红配股数据结构不符: {e}")
                        continue
                    except Exception as e:
                        logger.warning(f"{ts_code}的分红配股数据获取失败: {e}")
                        continue

                    # 检查结果是否为空
                    if dividend_df.is_empty():
                        logger.warning(f"{ts_code}没有分红配股数据")
                        continue

                    logger.info(f"获取到{ts_code}的{dividend_df.height}条分红配股数据")

                    # 离线模式下，只获取数据不存储
                    if not self.session:
                        result[ts_code] = dividend_df
                        logger.info(f"离线模式下，获取{ts_code}的分红配股数据完成")
                        continue

                    # 数据清洗和标准化
                    from src.database.models.stock import StockBasic

                    def _parse_date(value):
                        if value is None:
                            return None
                        if isinstance(value, datetime):
                            return value.date()
                        text = str(value).strip()
                        if not text or text in {'NaT', 'None', 'nan'}:
                            return None
                        try:
                            return datetime.strptime(text, "%Y-%m-%d").date()
                        except Exception:
                            return None

                    def _parse_float(value, default=0.0):
                        if value is None:
                            return default
                        if isinstance(value, (int, float)):
                            return float(value)
                        text = str(value).strip().replace(',', '')
                        if not text or text in {'None', 'nan', 'NaN', '--'}:
                            return default
                        for suffix in ['元', '股', '%']:
                            text = text.replace(suffix, '')
                        try:
                            return float(text)
                        except Exception:
                            return default

                    def _pick(row_dict, keys, default=0.0):
                        return _parse_float(
                            schema.pick_alias(row_dict, keys, default), default)

                    aliases = schema.DIVIDEND_ALIASES

                    # 获取股票名称
                    stock_basic = self.session.query(StockBasic).filter_by(ts_code=ts_code).first()
                    stock_name = stock_basic.name if stock_basic else ""

                    # 遍历数据，进行清洗和存储
                    dividend_rows = []
                    for row in dividend_df.iter_rows(named=True):
                        try:
                            # 检查row是否为None
                            if row is None:
                                logger.warning(f"处理{ts_code}的分红配股数据时，row为None，跳过")
                                continue

                            # 报告期作为分红年度
                            dividend_year = None
                            report_period = schema.pick_alias(row, aliases['report_period'])
                            if report_period:
                                if isinstance(report_period, str):
                                    dividend_year = report_period[:4]  # 提取年份
                                else:
                                    dividend_year = str(report_period.year)

                            report_date = _parse_date(schema.pick_alias(row, aliases['report_date']))
                            record_date = _parse_date(schema.pick_alias(row, aliases['record_date']))
                            ex_date = _parse_date(schema.pick_alias(row, aliases['ex_date']))

                            # 派息日（使用除权除息日作为派息日）
                            pay_date = ex_date

                            # 现金分红（10派X -> 每股X/10）
                            cash_div_ratio = _pick(row, aliases['cash_div_ratio'])
                            cash_div = cash_div_ratio / 10.0 if cash_div_ratio else 0.0

                            # 送转比例（10送转X -> 每股X/10）
                            share_div_ratio = _pick(row, aliases['share_div_ratio'])
                            share_div = share_div_ratio / 10.0 if share_div_ratio else 0.0

                            # 配股信息（10配X -> 每股X/10）
                            rights_issue_price = _pick(row, aliases['rights_issue_price'])
                            rights_issue_ratio_raw = _pick(row, aliases['rights_issue_ratio'])
                            rights_issue_ratio = rights_issue_ratio_raw / 10.0 if rights_issue_ratio_raw else 0.0

                            # 总派现金额（单位存在差异，仅在字段存在时保存）
                            total_div = _pick(row, aliases['total_div'], default=0.0)

                            dividend_rows.append({
                                'symbol': symbol,
                                'name': stock_name,
                                'dividend_year': dividend_year,
                                'report_date': report_date,
                                'record_date': record_date,
                                'ex_date': ex_date,
                                'pay_date': pay_date,
                                'cash_div': cash_div,
                                'share_div': share_div,
                                'total_div': total_div,
                                'rights_issue_price': rights_issue_price if rights_issue_price > 0 else None,
                                'rights_issue_ratio': rights_issue_ratio if rights_issue_ratio > 0 else None,
                            })

                        except TypeError as row_e:
                            logger.exception(f"处理{ts_code}的分红配股数据时发生类型错误: {row_e}")
                            continue
                        except (ConnectionError, TimeoutError, OSError) as row_e:
                            logger.exception(f"处理股票分红配股数据失败: {row_e}")
                            continue
                        except Exception as row_e:
                            logger.exception(f"处理{ts_code}的分红配股数据时发生未知错误: {row_e}")
                            continue

                    # 双键去重后批量写入
                    inserted, updated = self._save_dividend_rows(ts_code, dividend_rows)

                    # 每只股票提交一次事务
                    self.session.commit()
                    logger.info(f"{ts_code}的分红配股数据更新完成（新增{inserted}条，更新{updated}条）")

                except TypeError as e:
                    if self.session:
                        self.session.rollback()
                    logger.exception(f"获取{ts_code}的分红配股数据时发生类型错误: {e}")
                    continue
                except (ConnectionError, TimeoutError, OSError) as e:
                    if self.session:
                        self.session.rollback()
                    logger.exception(f"获取{ts_code}的分红配股数据失败: {e}")
                    continue
                except Exception as e:
                    if self.session:
                        self.session.rollback()
                    logger.exception(f"获取{ts_code}的分红配股数据时发生未知错误: {e}")
                    continue

            # 离线模式下返回结果
            if not self.session and result:
                return result

        except (ConnectionError, TimeoutError, OSError) as e:
            if self.session:
                self.session.rollback()
            logger.exception(f"更新股票分红配股数据失败: {e}")
            raise

    # ------------------------------------------------------------------
    # 标准 DataSource 接口（统一列名/单位/复权口径，供 DataFetcher 调用）
    # ------------------------------------------------------------------

    @staticmethod
    def _normalize_date_str(date_str: str) -> str:
        """将 YYYYMMDD 或 YYYY-MM-DD 统一为 YYYYMMDD（akshare 接口要求）"""
        return str(date_str).replace('-', '')

    def get_stock_data(self, ts_code: str, start_date: str, end_date: str,
                       freq: str = 'daily', adjustment_type: str = 'qfq'):
        """
        标准接口：获取股票日线数据，返回统一格式（原始价 + 复权因子）。

        akshare 的复权在 API 侧完成，无独立复权因子接口。
        这里获取不复权原始价(adjust="")，复权因子由 _normalize_kline 补齐 1.0，
        复权计算交由 DataFetcher._apply_adjustment 统一处理。

        Returns:
            pl.DataFrame: 归一化后的K线数据
        """
        try:
            symbol = to_symbol(ts_code)
            sd = self._normalize_date_str(start_date) if start_date else None
            ed = self._normalize_date_str(end_date) if end_date else None

            # 获取不复权原始价格
            df = schema.fetch_spec(
                schema.STOCK_HIST, symbol=symbol, period="daily",
                start_date=sd, end_date=ed, adjust="",
            )
            if df.is_empty():
                return pl.DataFrame()

            # 列名/单位/日期格式均取自上游契约，akshare 成交量单位为"手"
            normalized = self._normalize_kline(
                df, column_map=dict(schema.STOCK_HIST.column_map), ts_code=ts_code,
                volume_unit=schema.STOCK_HIST.volume_unit,
                date_format=schema.STOCK_HIST.date_format, include_factors=True,
            )

            # akshare 无复权因子接口，normalize 只能补 1.0；
            # 此时复权请求不会生效，显式告警避免上游误以为拿到的是复权价
            if adjustment_type in ('qfq', 'hfq') and not self._factor_warning_logged:
                self._factor_warning_logged = True
                logger.warning(
                    "akshare 数据源无真实复权因子（qfq/hfq_factor 均为 1.0），"
                    f"adjustment_type={adjustment_type} 请求将返回未复权价；"
                    "如需复权请改用 baostock 或 tdx 数据源")
            return normalized

        except Exception as e:
            logger.warning(f"akshare get_stock_data({ts_code}) 失败: {e}")
            return pl.DataFrame()

    def get_index_data(self, ts_code: str, start_date: str, end_date: str,
                       freq: str = 'daily'):
        """
        标准接口：获取指数日线数据，返回统一格式。

        Returns:
            pl.DataFrame: 归一化后的指数K线数据
        """
        try:
            sd = self._normalize_date_str(start_date) if start_date else None
            ed = self._normalize_date_str(end_date) if end_date else None

            df = schema.fetch_raw(
                schema.INDEX_DAILY_EM_EN.name, symbol=ts_code,
                start_date=sd, end_date=ed,
            )
            if df.is_empty():
                return pl.DataFrame()

            # 上游中英文列名随版本切换，由 select_spec 选择匹配的规格
            spec = schema.select_spec(
                (schema.INDEX_DAILY_EM_EN, schema.INDEX_DAILY_EM_CN), df)
            return self._normalize_kline(
                df, column_map=dict(spec.column_map), ts_code=ts_code,
                volume_unit=spec.volume_unit, date_format=spec.date_format,
                include_factors=True,
            )

        except Exception as e:
            logger.warning(f"akshare get_index_data({ts_code}) 失败: {e}")
            return pl.DataFrame()

    @handle_exception_with_retry(max_retries=3, retry_delay=2)
    def _fetch_etf_spot(self):
        """
        获取 ETF 实时行情（带统一重试装饰器）。

        网络类异常包装为 DataSourceConnectionError（可重试），
        重试 3 次后仍失败则抛出，由调用方捕获处理。
        """
        try:
            return schema.fetch_spec(schema.ETF_SPOT)
        except (ConnectionError, TimeoutError, OSError) as e:
            raise DataSourceConnectionError(
                source="akshare", message=f"获取 ETF 实时行情失败: {e}", cause=e) from e

    def update_etf_basic(self):
        """
        更新 ETF 基本信息
        使用 AkShare 的 fund_etf_spot_em() 获取 ETF 列表和名称
        """
        try:
            etf_df = self._fetch_etf_spot()
        except Exception as e:
            logger.error(f"从 AkShare 获取 ETF 基本信息失败，重试后仍失败: {e}")
            return None

        if etf_df.is_empty():
            logger.warning("从 AkShare 获取的 ETF 信息为空")
            return None

        logger.info(f"从 AkShare 获取到 {etf_df.height} 条 ETF 信息")

        logger.info(f"ETF DataFrame 列名: {etf_df.columns}")

        # 列名以 akshare_schema.ETF_SPOT 为准（离线/入库均用标准列名）
        etf_df = schema.resolve(etf_df, schema.ETF_SPOT)

        # 离线模式下，只获取数据不存储
        if not self.session:
            logger.info("离线模式下，跳过 ETF 基本信息存储")
            return etf_df

        from src.database.models.stock import StockBasic

        # 遍历数据，进行清洗和存储
        updated_count = 0
        for row in etf_df.iter_rows(named=True):
            try:
                # 提取 ETF 代码和名称
                symbol = str(row['symbol']).strip()
                name = row['name']

                if not symbol:
                    continue

                # 判断 ETF 所属市场（统一市场推断：51/58 -> SH，15/16 -> SZ）
                try:
                    ts_code = to_ts_code(symbol)
                except ValueError:
                    logger.warning(f"无法判断 ETF {symbol} 的市场，跳过")
                    continue

                # 查询 ETF 是否已存在
                stock = self.session.query(StockBasic).filter_by(ts_code=ts_code).first()

                if stock:
                    # 更新现有 ETF 名称
                    if stock.name != name:
                        logger.info(f"更新 ETF 名称: {ts_code} - {stock.name} -> {name}")
                        stock.name = name
                        updated_count += 1
                else:
                    # 创建新 ETF 信息
                    logger.info(f"新增 ETF: {ts_code} - {name}")
                    stock = StockBasic(
                        ts_code=ts_code,
                        symbol=symbol[:9] if len(symbol) > 9 else symbol,
                        name=name[:45] if len(name) > 45 else name,
                        status='L'
                    )
                    self.session.add(stock)
                    updated_count += 1

            except Exception as row_e:
                logger.exception(f"处理 ETF 基本信息失败: {row_e}")
                continue

        # 提交事务
        self.session.commit()
        logger.info(f"ETF 基本信息更新完成，共更新 {updated_count} 条记录")
        return etf_df
