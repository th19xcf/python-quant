#!/usr/bin/env python3

"""
中国股市量化分析系统主入口

仅负责应用组装与启动；数据同步等领域逻辑已收敛至 src.data.services。
"""

# 标准库导入
import argparse
import sys
from pathlib import Path

# 第三方库导入
from loguru import logger
from PySide6.QtWidgets import QApplication

# 添加项目根目录到Python路径
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.data.data_manager import DataManager
from src.data.services.sync_service import (
    sync_stock_fund_to_fund_basic,
    sync_tdx_index_to_database,
    sync_tdx_stock_to_database,
)
from src.database.db_manager import DatabaseManager
from src.plugin.plugin_manager import PluginManager
from src.ui.main_window import MainWindow
from src.ui.theme_manager import ThemeManager
from src.utils.cache_monitor import log_cache_stats

# 内部模块导入
from src.utils.config import config_manager, get_config
from src.utils.event_bus import EventType, publish, shutdown_event_bus
from src.utils.exception_handler import setup_global_exception_handler
from src.utils.exceptions import DataSourceException
from src.utils.logger import setup_logger
from src.utils.memory_manager import global_memory_manager


def parse_args():
    """
    解析命令行参数
    """
    parser = argparse.ArgumentParser(description='中国股市量化分析系统')
    parser.add_argument('--init-db', action='store_true', help='初始化数据库表')
    parser.add_argument('--update-stock', action='store_true', help='从通达信数据源同步股票信息到数据库')
    parser.add_argument('--update-index', action='store_true', help='以通达信指数代码为基准更新 index_basic（Baostock/AkShare 补全）')
    parser.add_argument('--update-fund', action='store_true', help='将 stock_basic 中基金迁移到 fund_basic 并补全信息')
    parser.add_argument('--plugins', action='store_true', help='显示已加载的插件')
    return parser.parse_args()


def _initialize_system(config):
    """初始化系统组件

    Args:
        config: 配置对象

    Returns:
        tuple: (plugin_manager, cpu_count)
    """
    import os

    setup_global_exception_handler()
    logger.info("全局异常处理器初始化成功")

    config_manager.start_watching(interval=5)
    logger.info("配置热加载功能已启动")

    setup_logger(config)
    logger.info("日志系统初始化成功")

    plugin_manager = PluginManager(config)
    logger.info("插件管理器初始化成功")

    loaded_count = plugin_manager.load_plugins()
    logger.info(f"插件加载完成，共加载 {loaded_count} 个插件")

    cpu_count = os.cpu_count() or 4
    os.environ['POLARS_MAX_THREADS'] = str(cpu_count)
    logger.info(f"已通过环境变量设置Polars线程池大小为 {cpu_count}")

    initialized_count = plugin_manager.initialize_plugins()
    logger.info(f"插件初始化完成，共初始化 {initialized_count} 个插件")

    return plugin_manager, cpu_count


def _display_plugins(plugin_manager):
    """显示已加载的插件

    Args:
        plugin_manager: 插件管理器
    """
    logger.info("已加载的插件列表:")
    for plugin_info in plugin_manager.get_all_plugin_info():
        logger.info(f"  - {plugin_info['name']} (v{plugin_info['version']}) - {plugin_info['description']}")


def _handle_update_stock_arg(config):
    """处理股票更新参数

    Args:
        config: 配置对象

    Returns:
        bool: 是否执行了股票更新
    """
    logger.info("检测到 --update-stock 参数，将执行股票信息同步")

    db_manager = None
    try:
        db_manager = DatabaseManager(config)
        db_manager.connect()
        logger.info("数据库连接成功")

        try:
            db_manager.create_tables()
            logger.info("数据库表创建/更新成功")
        except (OSError, RuntimeError) as table_e:
            logger.warning(f"创建数据库表时发生错误: {table_e}")

        sync_tdx_stock_to_database(config, db_manager)

        from src.data.akshare_handler import AkShareHandler
        akshare_handler = AkShareHandler(config, db_manager)
        logger.info("开始更新 ETF 基本信息...")
        try:
            etf_result = akshare_handler.update_etf_basic()
            if etf_result is not None:
                logger.info("ETF 基本信息更新完成")
        except DataSourceException as etf_e:
            logger.warning(f"更新 ETF 基本信息失败: {etf_e}")

        db_manager.cleanup()
        logger.info("数据库资源已清理")
        return True

    except (OSError, RuntimeError) as db_e:
        logger.error(f"数据库连接失败，无法执行同步: {db_e}")
        return True


def _handle_update_index_arg(config):
    """处理指数更新参数。"""
    logger.info("检测到 --update-index 参数，将执行指数信息同步")

    db_manager = None
    try:
        db_manager = DatabaseManager(config)
        db_manager.connect()
        logger.info("数据库连接成功")

        try:
            db_manager.create_tables()
            logger.info("数据库表创建/更新成功")
        except (OSError, RuntimeError) as table_e:
            logger.warning(f"创建数据库表时发生错误: {table_e}")

        sync_tdx_index_to_database(config, db_manager)
        db_manager.cleanup()
        logger.info("数据库资源已清理")
        return True

    except (OSError, RuntimeError) as db_e:
        logger.error(f"数据库连接失败，无法执行指数同步: {db_e}")
        return True


def _handle_update_fund_arg(config):
    """处理基金迁移参数。"""
    logger.info("检测到 --update-fund 参数，将执行基金迁移和补全")

    db_manager = None
    try:
        db_manager = DatabaseManager(config)
        db_manager.connect()
        logger.info("数据库连接成功")

        try:
            db_manager.create_tables()
            logger.info("数据库表创建/更新成功")
        except (OSError, RuntimeError) as table_e:
            logger.warning(f"创建数据库表时发生错误: {table_e}")

        sync_stock_fund_to_fund_basic(config, db_manager)
        db_manager.cleanup()
        logger.info("数据库资源已清理")
        return True

    except (OSError, RuntimeError) as db_e:
        logger.error(f"数据库连接失败，无法执行基金迁移: {db_e}")
        return True


def _initialize_data_manager(config, plugin_manager):
    """初始化数据管理器

    Args:
        config: 配置对象
        plugin_manager: 插件管理器

    Returns:
        DataManager: 数据管理器实例
    """
    db_manager = None
    try:
        db_manager = DatabaseManager(config)
        db_manager.connect()
        logger.info("数据库连接成功")

        try:
            db_manager.create_tables()
            logger.info("数据库表创建/更新成功")
        except (OSError, RuntimeError) as table_e:
            logger.warning(f"创建数据库表时发生错误: {table_e}")

        data_manager = DataManager(config, db_manager, plugin_manager)
        logger.info("数据管理器初始化成功")
    except (OSError, RuntimeError) as db_e:
        logger.warning(f"数据库连接失败，将以离线模式运行: {db_e}")
        data_manager = DataManager(config, None, plugin_manager)
        logger.info("数据管理器（离线模式）初始化成功")

    return data_manager


def _cleanup_system(plugin_manager, db_manager):
    """清理系统资源

    Args:
        plugin_manager: 插件管理器
        db_manager: 数据库管理器
    """
    try:
        global_memory_manager.stop_monitoring()
        memory_usage = global_memory_manager.get_memory_usage()
        logger.info(f"最终内存使用: {memory_usage['process_rss_mb']:.2f} MB ({memory_usage['process_percent']:.1f}%)")
    except Exception as e:
        logger.warning(f"停止内存监控时发生错误: {e}")

    publish(EventType.SYSTEM_SHUTDOWN)
    log_cache_stats()

    try:
        if db_manager:
            db_manager.cleanup()
    except (OSError, RuntimeError) as cleanup_e:
        logger.warning(f"清理数据库资源时发生错误: {cleanup_e}")

    if plugin_manager:
        plugin_manager.shutdown_plugins()

    config_manager.stop_watching()
    logger.info("配置热加载功能已停止")

    shutdown_event_bus()
    logger.info("事件总线已关闭")

    logger.info("系统已关闭")


def main():
    """主函数"""
    args = parse_args()

    plugin_manager = None
    db_manager = None

    try:
        config = get_config()
        logger.info("配置加载成功")

        plugin_manager, cpu_count = _initialize_system(config)

        if args.plugins:
            _display_plugins(plugin_manager)
            return

        if args.update_stock:
            _handle_update_stock_arg(config)
            return

        if args.update_index:
            _handle_update_index_arg(config)
            return

        if args.update_fund:
            _handle_update_fund_arg(config)
            return

        data_manager = _initialize_data_manager(config, plugin_manager)

        app = QApplication(sys.argv)
        app.setApplicationName("中国股市量化分析系统")

        ThemeManager.set_dark_theme(app)

        main_window = MainWindow(config, data_manager, plugin_manager)
        main_window.showMaximized()

        publish(EventType.SYSTEM_INIT, app=app, config=config, data_manager=data_manager)
        logger.info("中国股市量化分析系统启动成功")

        global_memory_manager.start_monitoring()
        logger.info("内存监控已启动")

        memory_usage = global_memory_manager.get_memory_usage()
        logger.info(f"初始内存使用: {memory_usage['process_rss_mb']:.2f} MB ({memory_usage['process_percent']:.1f}%)")

        log_cache_stats()

        sys.exit(app.exec())

    except (OSError, RuntimeError) as e:
        logger.exception(f"系统启动失败: {e}")
        sys.exit(1)
    finally:
        _cleanup_system(plugin_manager, db_manager)


if __name__ == "__main__":
    main()
