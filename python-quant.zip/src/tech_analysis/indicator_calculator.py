#!/usr/bin/env python3

"""
指标计算工具模块，提供各种技术指标的计算方法
"""

import polars as pl
from loguru import logger

from ..utils.memory_optimizer import MemoryOptimizer
from .indicators import (
    calculate_cost_indicators,
    calculate_market_breadth_indicators,
    calculate_oscillator_indicators,
    calculate_trend_indicators,
    calculate_volatility_indicators,
    calculate_volume_indicators,
)
from .utils import (
    cleanup_temp_columns,
    collect_indicator_windows,
    get_indicator_params,
    merge_used_windows,
)


def calculate_ma_polars(df, windows=None):
    """
    使用Polars计算移动平均线（Lazy API优化）
    支持链式调用，返回与输入类型一致（DataFrame或LazyFrame）

    Args:
        df: Polars DataFrame或LazyFrame
        windows: 移动平均窗口列表

    Returns:
        pl.DataFrame或pl.LazyFrame: 包含移动平均线的DataFrame或LazyFrame
    """
    # 调用批量计算函数，减少代码冗余
    if windows is None:
        windows = [5, 10, 20, 60]
    return calculate_multiple_indicators_polars(df, ['ma'], windows=windows)


def calculate_vol_ma_polars(df, windows=None):
    """
    使用Polars计算成交量移动平均线（Lazy API优化）
    支持链式调用，返回与输入类型一致（DataFrame或LazyFrame）

    Args:
        df: Polars DataFrame或LazyFrame
        windows: 移动平均窗口列表

    Returns:
        pl.DataFrame或pl.LazyFrame: 包含成交量移动平均线的DataFrame或LazyFrame
    """
    # 调用批量计算函数，减少代码冗余
    if windows is None:
        windows = [5, 10]
    return calculate_multiple_indicators_polars(df, ['vol_ma'], vol_ma_windows=windows)


def preprocess_data_polars(df):
    """
    使用Polars进行数据预处理
    - 检查必要列是否存在
    - 转换为高效数值类型（float32替代float64）
    - 处理缺失值
    - 保留复权价格字段

    Args:
        df: Polars DataFrame

    Returns:
        pl.DataFrame: 预处理后的数据
    """
    # 检查必要列是否存在，只检查核心列
    core_columns = ['close']  # 只检查收盘价，其他列可选
    for col in core_columns:
        if col not in df.columns:
            raise ValueError(f"数据中没有{col}列")

    # 快速路径：数据已处于优化状态（无待转换列且Float32列无NaN）时，
    # 跳过 MemoryOptimizer 全量优化与 fill_nan，避免重复预处理开销。
    # 校验条件从严：任一列不满足稳定条件即走完整预处理，宁多算不错过。
    if _is_already_preprocessed(df):
        return df

    # 直接使用MemoryOptimizer进行全面的内存优化
    optimized_df = MemoryOptimizer.optimize_dataframe(df, enable_sparse=True)

    # 处理缺失值
    # 只填充数值列的缺失值
    numeric_cols = [col for col in optimized_df.columns if optimized_df[col].dtype in [pl.Float32, pl.Int32, pl.Int16, pl.Int8]]
    if numeric_cols:
        optimized_df = optimized_df.with_columns(
            [pl.col(col).fill_nan(0.0) for col in numeric_cols]
        )

    MemoryOptimizer.print_memory_stats(optimized_df, "预处理后数据")
    return optimized_df


# 预处理稳定 dtype 集合（与 MemoryOptimizer.optimize_dataframe 的优化目标一致）
_PREPROCESS_STABLE_DTYPES = frozenset([
    pl.Float32, pl.Int32, pl.Int16, pl.Int8, pl.Date, pl.Boolean, pl.Categorical
])

# 价格/成交量/复权因子列按设计保留 Float64，不会被 optimize_dataframe 降精度
_PREPROCESS_STABLE_FLOAT64_COLS = frozenset(
    MemoryOptimizer.COLUMN_TYPE_MAP['price_cols'] + MemoryOptimizer.COLUMN_TYPE_MAP['volume_cols']
)


def _is_already_preprocessed(df):
    """
    判断数据是否已处于预处理后的稳定状态（幂等校验）

    条件从严：全部列为稳定 dtype（Float64 仅限价格/成交量列），
    且 Float32 列无 NaN（fill_nan 的目标列）。

    Args:
        df: Polars DataFrame

    Returns:
        bool: True 表示可安全跳过完整预处理
    """
    float32_cols = []
    for col in df.columns:
        dtype = df[col].dtype
        if dtype in _PREPROCESS_STABLE_DTYPES:
            if dtype == pl.Float32:
                float32_cols.append(col)
            continue
        if dtype == pl.Float64 and col in _PREPROCESS_STABLE_FLOAT64_COLS:
            continue
        # 其余 dtype（Int64/UInt*/Utf8/Decimal/Datetime/Null/其他列的Float64等）
        # 均可能被 optimize_dataframe 转换，不可跳过
        return False

    # Float32 列存在 NaN 时仍需走完整路径执行 fill_nan
    if float32_cols:
        nan_total = df.select(
            pl.sum_horizontal(pl.col(c).is_nan().sum() for c in float32_cols).alias('_nan_total')
        ).item()
        if nan_total and nan_total > 0:
            return False
    return True


def sample_data_polars(df, target_points=1000, strategy='adaptive'):
    """
    对Polars数据进行采样，减少数据量，提高图表渲染速度
    支持多种采样策略，包括均匀采样和自适应采样

    Args:
        df: Polars DataFrame或LazyFrame
        target_points: 目标采样点数
        strategy: 采样策略，可选值：'uniform'（均匀采样）、'adaptive'（自适应采样）

    Returns:
        pl.DataFrame或pl.LazyFrame: 采样后的数据
    """
    # 检查是否为LazyFrame
    is_lazy = isinstance(df, pl.LazyFrame)

    # 1. 快速路径：如果目标点数大于等于数据行数，直接返回
    if is_lazy:
        # 对于LazyFrame，我们只能在必要时才执行计算
        # 尝试使用lazy的方式估算行数，但这可能不总是准确
        # 所以我们直接进入后续逻辑，让Polars优化器处理
        pass
    else:
        data_len = len(df)
        if data_len <= target_points:
            return df

    if strategy == 'uniform':
        if is_lazy:
            # 对于LazyFrame，使用nth_sample进行均匀采样，这是更高效的方式
            return df.nth_sample(target_points)
        else:
            # 对于DataFrame，使用nth_sample
            data_len = len(df)
            sample_interval = data_len // target_points
            if sample_interval < 1:
                sample_interval = 1
            return df.nth(range(0, data_len, sample_interval)).head(target_points)
    elif strategy == 'adaptive':
        if is_lazy:
            # 对于LazyFrame，返回原始数据，让Polars优化器处理
            # 自适应采样需要多次数据扫描，对于LazyFrame可能效率不高
            # 这里选择直接返回原始数据，避免触发不必要的计算
            return df.head(target_points)
        else:
            # 对于DataFrame，执行自适应采样
            data_len = len(df)
            if data_len <= target_points:
                return df

            # 计算价格变化
            df_with_change = df.with_columns(
                pl.col('close').diff().abs().alias('price_change')
            )

            # 计算变化率的分位数
            change_quantile = df_with_change['price_change'].quantile(0.75)

            # 标记重要数据点
            important_points = df_with_change.filter(pl.col('price_change') > change_quantile)
            important_count = len(important_points)

            if important_count >= target_points:
                return important_points.head(target_points)

            # 计算需要从非重要数据点中采样的数量
            regular_count = target_points - important_count

            # 从非重要数据点中采样
            regular_points = df_with_change.filter(pl.col('price_change') <= change_quantile)
            regular_len = len(regular_points)

            if regular_len <= regular_count:
                # 非重要数据点不足，直接合并
                combined = important_points.vstack(regular_points)
            else:
                # 均匀采样非重要数据点
                sample_interval = regular_len // regular_count
                if sample_interval < 1:
                    sample_interval = 1
                sampled_regular = regular_points.nth(range(0, regular_len, sample_interval)).head(regular_count)
                combined = important_points.vstack(sampled_regular)

            # 按时间排序
            sampled_data = combined.sort(by=df.columns[0])

            # 确保包含首尾数据点
            first_point = df.head(1)
            last_point = df.tail(1)

            # 检查并添加首尾数据点
            if not sampled_data.filter(pl.col(df.columns[0]) == first_point[0, df.columns[0]]).is_empty():
                first_point = None
            if not sampled_data.filter(pl.col(df.columns[0]) == last_point[0, df.columns[0]]).is_empty():
                last_point = None

            if first_point is not None:
                sampled_data = first_point.vstack(sampled_data)
            if last_point is not None:
                sampled_data = sampled_data.vstack(last_point)

            # 确保采样数量不超过目标数量
            if len(sampled_data) > target_points:
                sampled_data = sampled_data.head(target_points)

            return sampled_data
    else:
        raise ValueError(f"不支持的采样策略: {strategy}")


def calculate_macd_polars(df, fast_period=12, slow_period=26, signal_period=9):
    """
    使用Polars计算MACD指标（Lazy API优化）
    支持链式调用，返回与输入类型一致（DataFrame或LazyFrame）

    Args:
        df: Polars DataFrame或LazyFrame
        fast_period: 快速EMA周期
        slow_period: 慢速EMA周期
        signal_period: 信号线EMA周期

    Returns:
        pl.DataFrame或pl.LazyFrame: 包含MACD指标的DataFrame或LazyFrame
    """
    # 调用批量计算函数，减少代码冗余
    return calculate_multiple_indicators_polars(df, ['macd'],
                                              fast_period=fast_period,
                                              slow_period=slow_period,
                                              signal_period=signal_period)


def calculate_rsi_polars(df, windows=None):
    """
    使用Polars批量计算RSI指标（Lazy API优化）
    优化：使用EMA替代普通移动平均线计算平均上涨和下跌幅度
    支持链式调用，返回与输入类型一致（DataFrame或LazyFrame）

    Args:
        df: Polars DataFrame或LazyFrame
        windows: RSI计算窗口列表，默认为[14]

    Returns:
        pl.DataFrame或pl.LazyFrame: 包含RSI指标的DataFrame或LazyFrame
    """
    if windows is None:
        windows = [14]
    # 调用批量计算函数，减少代码冗余
    return calculate_multiple_indicators_polars(df, ['rsi'], rsi_windows=windows)


def calculate_kdj_polars(df, windows=None):
    """
    使用Polars批量计算KDJ指标（Lazy API优化）
    支持链式调用，返回与输入类型一致（DataFrame或LazyFrame）

    Args:
        df: Polars DataFrame或LazyFrame
        windows: KDJ计算窗口列表，默认为[14]

    Returns:
        pl.DataFrame或pl.LazyFrame: 包含KDJ指标的DataFrame或LazyFrame
    """
    if windows is None:
        windows = [14]
    # 调用批量计算函数，减少代码冗余
    return calculate_multiple_indicators_polars(df, ['kdj'], kdj_windows=windows)


def calculate_boll_polars(df, windows=None, std_dev=2.0):
    """
    使用Polars批量计算Boll指标（布林带），优化性能
    支持链式调用，返回与输入类型一致（DataFrame或LazyFrame）

    Args:
        df: Polars DataFrame或LazyFrame
        windows: Boll计算窗口列表，默认为[20]
        std_dev: 标准差倍数，默认为2.0

    Returns:
        pl.DataFrame或pl.LazyFrame: 包含Boll指标的DataFrame或LazyFrame
    """
    if windows is None:
        windows = [20]
    # 调用批量计算函数，减少代码冗余，使用与其他指标一致的参数命名
    return calculate_multiple_indicators_polars(df, ['boll'], boll_windows=windows, boll_std_dev=std_dev)


def calculate_wr_polars(df, windows=None):
    """
    使用Polars批量计算WR指标（威廉指标），优化性能，模拟通达信WR(10,6)效果
    支持链式调用，返回与输入类型一致（DataFrame或LazyFrame）

    Args:
        df: Polars DataFrame或LazyFrame
        windows: WR计算窗口列表，默认为[10, 6]

    Returns:
        pl.DataFrame或pl.LazyFrame: 包含WR指标的DataFrame或LazyFrame
    """
    if windows is None:
        windows = [10, 6]  # 通达信默认使用WR10和WR6
    # 调用批量计算函数，减少代码冗余
    return calculate_multiple_indicators_polars(df, ['wr'], wr_windows=windows)


def calculate_dmi_polars(df, windows=None):
    """
    使用Polars批量计算DMI指标（趋向指标）
    支持链式调用，返回与输入类型一致（DataFrame或LazyFrame）

    Args:
        df: Polars DataFrame或LazyFrame
        windows: DMI计算窗口列表，默认为[14]

    Returns:
        pl.DataFrame或pl.LazyFrame: 包含DMI指标的DataFrame或LazyFrame
    """
    if windows is None:
        windows = [14]
    if windows is None:
        windows = [14]  # 通达信默认使用DMI14
    # 调用批量计算函数，减少代码冗余
    return calculate_multiple_indicators_polars(df, ['dmi'], dmi_windows=windows)


def calculate_cci_polars(df, windows=None):
    """
    使用Polars批量计算CCI指标（商品通道指标）
    支持链式调用，返回与输入类型一致（DataFrame或LazyFrame）

    Args:
        df: Polars DataFrame或LazyFrame
        windows: CCI计算窗口列表，默认为[14]

    Returns:
        pl.DataFrame或pl.LazyFrame: 包含CCI指标的DataFrame或LazyFrame
    """
    if windows is None:
        windows = [14]
    if windows is None:
        windows = [14]  # 通达信默认使用CCI14
    # 调用批量计算函数，减少代码冗余
    return calculate_multiple_indicators_polars(df, ['cci'], cci_windows=windows)


def calculate_roc_polars(df, windows=None):
    """
    使用Polars批量计算ROC指标（变化率指标）
    支持链式调用，返回与输入类型一致（DataFrame或LazyFrame）

    Args:
        df: Polars DataFrame或LazyFrame
        windows: ROC计算窗口列表，默认为[12]

    Returns:
        pl.DataFrame或pl.LazyFrame: 包含ROC指标的DataFrame或LazyFrame
    """
    if windows is None:
        windows = [12]
    if windows is None:
        windows = [12]  # 通达信默认使用ROC12
    # 调用批量计算函数，减少代码冗余
    return calculate_multiple_indicators_polars(df, ['roc'], roc_windows=windows)


def calculate_mtm_polars(df, windows=None):
    """
    使用Polars批量计算MTM指标（动量指标）
    支持链式调用，返回与输入类型一致（DataFrame或LazyFrame）

    Args:
        df: Polars DataFrame或LazyFrame
        windows: MTM计算窗口列表，默认为[12]

    Returns:
        pl.DataFrame或pl.LazyFrame: 包含MTM指标的DataFrame或LazyFrame
    """
    if windows is None:
        windows = [12]
    if windows is None:
        windows = [12]  # 通达信默认使用MTM12
    # 调用批量计算函数，减少代码冗余
    return calculate_multiple_indicators_polars(df, ['mtm'], mtm_windows=windows)


def calculate_obv_polars(df):
    """
    使用Polars计算OBV指标（能量潮）
    支持链式调用，返回与输入类型一致（DataFrame或LazyFrame）

    Args:
        df: Polars DataFrame或LazyFrame

    Returns:
        pl.DataFrame或pl.LazyFrame: 包含OBV指标的DataFrame或LazyFrame
    """
    # 调用批量计算函数，减少代码冗余
    return calculate_multiple_indicators_polars(df, ['obv'])


def calculate_vr_polars(df, windows=None):
    """
    使用Polars批量计算VR指标（成交量比率）
    支持链式调用，返回与输入类型一致（DataFrame或LazyFrame）

    Args:
        df: Polars DataFrame或LazyFrame
        windows: VR计算窗口列表，默认为[26]

    Returns:
        pl.DataFrame或pl.LazyFrame: 包含VR指标的DataFrame或LazyFrame
    """
    if windows is None:
        windows = [26]
    if windows is None:
        windows = [26]  # 通达信默认使用VR26
    # 调用批量计算函数，减少代码冗余
    return calculate_multiple_indicators_polars(df, ['vr'], vr_windows=windows)


def calculate_psy_polars(df, windows=None):
    """
    使用Polars批量计算PSY指标（心理线）
    支持链式调用，返回与输入类型一致（DataFrame或LazyFrame）

    Args:
        df: Polars DataFrame或LazyFrame
        windows: PSY计算窗口列表，默认为[12]

    Returns:
        pl.DataFrame或pl.LazyFrame: 包含PSY指标的DataFrame或LazyFrame
    """
    if windows is None:
        windows = [12]
    if windows is None:
        windows = [12]  # 通达信默认使用PSY12
    # 调用批量计算函数，减少代码冗余
    return calculate_multiple_indicators_polars(df, ['psy'], psy_windows=windows)


def calculate_trix_polars(df, windows=None, signal_period=9):
    """
    使用Polars批量计算TRIX指标（三重指数平滑）
    支持链式调用，返回与输入类型一致（DataFrame或LazyFrame）

    Args:
        df: Polars DataFrame或LazyFrame
        windows: TRIX计算窗口列表，默认为[12]
        signal_period: TRIX信号线周期，默认为9

    Returns:
        pl.DataFrame或pl.LazyFrame: 包含TRIX指标的DataFrame或LazyFrame
    """
    if windows is None:
        windows = [12]
    if windows is None:
        windows = [12]  # 通达信默认使用TRIX12
    # 调用批量计算函数，减少代码冗余
    return calculate_multiple_indicators_polars(df, ['trix'], trix_windows=windows, trix_signal_period=signal_period)


def calculate_brar_polars(df, windows=None):
    """
    使用Polars批量计算BRAR指标（情绪指标）
    支持链式调用，返回与输入类型一致（DataFrame或LazyFrame）

    Args:
        df: Polars DataFrame或LazyFrame
        windows: BRAR计算窗口列表，默认为[26]

    Returns:
        pl.DataFrame或pl.LazyFrame: 包含BRAR指标的DataFrame或LazyFrame
    """
    if windows is None:
        windows = [26]
    if windows is None:
        windows = [26]  # 通达信默认使用BRAR26
    # 调用批量计算函数，减少代码冗余
    return calculate_multiple_indicators_polars(df, ['brar'], brar_windows=windows)


def calculate_asi_polars(df, signal_period=20):
    """
    使用Polars计算ASI指标（振动升降指标）
    支持链式调用，返回与输入类型一致（DataFrame或LazyFrame）

    Args:
        df: Polars DataFrame或LazyFrame
        signal_period: ASI信号线周期，默认为20

    Returns:
        pl.DataFrame或pl.LazyFrame: 包含ASI指标的DataFrame或LazyFrame
    """
    # 调用批量计算函数，减少代码冗余
    return calculate_multiple_indicators_polars(df, ['asi'], asi_signal_period=signal_period)


def calculate_emv_polars(df, windows=None, constant=100000000):
    """
    使用Polars批量计算EMV指标（简易波动指标）
    支持链式调用，返回与输入类型一致（DataFrame或LazyFrame）

    Args:
        df: Polars DataFrame或LazyFrame
        windows: EMV计算窗口列表，默认为[14]
        constant: 常数，用于调整EMV的数值大小，默认为100000000

    Returns:
        pl.DataFrame或pl.LazyFrame: 包含EMV指标的DataFrame或LazyFrame
    """
    if windows is None:
        windows = [14]
    if windows is None:
        windows = [14]  # 通达信默认使用EMV14
    # 调用批量计算函数，减少代码冗余
    return calculate_multiple_indicators_polars(df, ['emv'], emv_windows=windows, emv_constant=constant)


def calculate_mcst_polars(df, windows=None):
    """
    使用Polars批量计算MCST指标（市场成本）
    支持链式调用，返回与输入类型一致（DataFrame或LazyFrame）

    Args:
        df: Polars DataFrame或LazyFrame
        windows: MCST计算窗口列表，默认为[12]

    Returns:
        pl.DataFrame或pl.LazyFrame: 包含MCST指标的DataFrame或LazyFrame
    """
    if windows is None:
        windows = [12]
    if windows is None:
        windows = [12]  # 通达信默认使用MCST12
    # 调用批量计算函数，减少代码冗余
    return calculate_multiple_indicators_polars(df, ['mcst'], mcst_windows=windows)


def calculate_dma_polars(df, short_period=10, long_period=50, signal_period=10):
    """
    使用Polars计算DMA指标（平均线差）
    支持链式调用，返回与输入类型一致（DataFrame或LazyFrame）

    Args:
        df: Polars DataFrame或LazyFrame
        short_period: 短期MA周期，默认10
        long_period: 长期MA周期，默认50
        signal_period: DMA信号线周期，默认10

    Returns:
        pl.DataFrame或pl.LazyFrame: 包含DMA指标的DataFrame或LazyFrame
    """
    return calculate_multiple_indicators_polars(df, ['dma'],
                                               dma_short_period=short_period,
                                               dma_long_period=long_period,
                                               dma_signal_period=signal_period)


def calculate_fsl_polars(df):
    """
    使用Polars计算FSL指标（分水岭指标）
    支持链式调用，返回与输入类型一致（DataFrame或LazyFrame）

    Args:
        df: Polars DataFrame或LazyFrame

    Returns:
        pl.DataFrame或pl.LazyFrame: 包含FSL指标的DataFrame或LazyFrame
    """
    return calculate_multiple_indicators_polars(df, ['fsl'])


def calculate_sar_polars(df, af_step=0.02, max_af=0.2):
    """
    使用Polars计算SAR指标（抛物线转向指标）
    支持链式调用，返回与输入类型一致（DataFrame或LazyFrame）

    Args:
        df: Polars DataFrame或LazyFrame
        af_step: 加速因子步长，默认0.02
        max_af: 最大加速因子，默认0.2

    Returns:
        pl.DataFrame或pl.LazyFrame: 包含SAR指标的DataFrame或LazyFrame
    """
    return calculate_multiple_indicators_polars(df, ['sar'],
                                               sar_af_step=af_step,
                                               sar_max_af=max_af)


def calculate_vol_tdx_polars(df, ma_period=5):
    """
    使用Polars计算VOL-TDX指标（成交量趋势）
    支持链式调用，返回与输入类型一致（DataFrame或LazyFrame）

    Args:
        df: Polars DataFrame或LazyFrame
        ma_period: 移动平均周期，默认5

    Returns:
        pl.DataFrame或pl.LazyFrame: 包含VOL-TDX指标的DataFrame或LazyFrame
    """
    return calculate_multiple_indicators_polars(df, ['vol_tdx'],
                                               vol_tdx_ma_period=ma_period)


def calculate_cr_polars(df, windows=None):
    """
    使用Polars计算CR指标（能量指标）
    支持链式调用，返回与输入类型一致（DataFrame或LazyFrame）

    Args:
        df: Polars DataFrame或LazyFrame
        windows: CR计算窗口列表，默认为[26]

    Returns:
        pl.DataFrame或pl.LazyFrame: 包含CR指标的DataFrame或LazyFrame
    """
    if windows is None:
        windows = [26]
    return calculate_multiple_indicators_polars(df, ['cr'], cr_windows=windows)


def calculate_multiple_indicators_polars(df, indicator_types=None, *, optimize_memory=False, **params):
    """
    统一的多指标批量计算函数，将所有指标计算合并到单个查询计划
    支持链式调用，返回与输入类型一致（DataFrame或LazyFrame）

    Args:
        df: Polars DataFrame或LazyFrame
        indicator_types: 指标类型列表，默认计算所有指标
        optimize_memory: 是否在结果落地前执行 dtype 压缩，默认关闭。
            由调用方在缓存落地前决定是否开启；开启后指标列会降级为
            Float32，EMA 等递推指标会在 Float32 下执行并累积误差
        **params: 指标计算参数

    Returns:
        pl.DataFrame或pl.LazyFrame: 包含所有计算指标的DataFrame或LazyFrame
    """
    from src.utils.lazy_optimizer import execute_optimized_pipeline, optimize_lazy_frame

    # 默认计算所有指标
    if indicator_types is None:
        indicator_types = ['ma', 'rsi', 'kdj', 'vol_ma', 'wr', 'boll', 'macd', 'dmi', 'cci', 'roc', 'mtm', 'obv', 'vr', 'psy', 'trix', 'brar', 'asi', 'emv', 'mcst', 'abi', 'adl', 'adr', 'obos']

    # 1. 收集所有需要计算的指标和参数
    indicator_params = get_indicator_params(**params)

    # 2. 预计算共享的窗口列（最高价、最低价的窗口统计）
    need_high_low = any(indicator in indicator_types for indicator in ['kdj', 'wr', 'boll'])

    # 3. 使用Lazy API构建查询，确保所有计算在单个查询计划中执行
    lazy_df = df.lazy()

    # 步骤1: 添加共享的窗口列
    # 只创建实际需要的共享窗口列
    if need_high_low:
        # 收集实际使用的窗口大小
        indicator_windows = collect_indicator_windows(indicator_types, indicator_params)
        used_windows = merge_used_windows(indicator_windows)

        # 只创建实际使用的窗口列；单次 with_columns 提交全部窗口表达式，
        # 避免逐窗口生成独立的投影节点
        # min_samples=1 确保从第一个数据点开始计算（与通达信 HHV/LLV 展示口径一致）
        lazy_df = lazy_df.with_columns([
            expr
            for window in used_windows
            for expr in (
                pl.col('high').rolling_max(window_size=window, min_samples=1).alias(f'high_n_{window}'),
                pl.col('low').rolling_min(window_size=window, min_samples=1).alias(f'low_n_{window}'),
            )
        ])

    # 步骤2: 计算趋势类指标
    lazy_df = calculate_trend_indicators(lazy_df, indicator_types, **params)

    # 步骤3: 计算震荡类指标
    lazy_df = calculate_oscillator_indicators(lazy_df, indicator_types, **params)

    # 步骤4: 计算成交量类指标
    lazy_df = calculate_volume_indicators(lazy_df, indicator_types, **params)

    # 步骤5: 计算波动率类指标
    lazy_df = calculate_volatility_indicators(lazy_df, indicator_types, **params)

    # 步骤6: 计算成本类指标
    lazy_df = calculate_cost_indicators(lazy_df, indicator_types, **params)

    # 步骤7: 计算大势型指标
    lazy_df = calculate_market_breadth_indicators(lazy_df, indicator_types, **params)

    # 清理临时列
    lazy_df = cleanup_temp_columns(lazy_df, indicator_types, indicator_params)

    # 优化查询计划，充分利用Polars的并行计算能力
    lazy_df = optimize_lazy_frame(lazy_df)

    # 检查输入类型并返回相应的结果
    if isinstance(df, pl.LazyFrame):
        return lazy_df

    # eager 路径：单次 collect。dtype 压缩默认关闭——execute_optimized_pipeline
    # 内部已含一次压缩，此处再压是重复开销；且其惰性计划级压缩会把全部数值列
    # 降级 Float32 后再执行 EMA 递推，与通达信口径产生可观测偏差
    result = execute_optimized_pipeline(lazy_df, optimize_memory=optimize_memory)
    logger.debug("指标计算结果: {} 行 x {} 列", result.height, result.width)
    return result


def calculate_indicators_parallel(data, indicator_types, max_workers=None, *, optimize_memory=False, **params):
    """
    已废弃：单标的多指标计算请直接使用 calculate_multiple_indicators_polars。

    原实现按指标组拆分查询计划并用 ThreadPoolExecutor 并行提交，存在三个问题：
    每组重复计算共享中间列（high_n/low_n、公共 EMA）；外层线程池与 Polars
    内部线程池超额订阅（单次 collect 已能用满所有核）；按"结果首列是对齐键"
    的启发式合并。现保留为薄包装，仅做 API 兼容，max_workers 不再生效。

    Args:
        data: 输入数据（Polars DataFrame或pandas DataFrame）
        indicator_types: 指标类型列表
        max_workers: 已废弃，仅为 API 兼容保留
        optimize_memory: 是否在结果落地前执行 dtype 压缩，默认关闭，
            由调用方在缓存落地前决定
        **params: 指标计算参数

    Returns:
        pl.DataFrame: 包含所有计算指标的DataFrame
    """
    import warnings

    warnings.warn(
        "calculate_indicators_parallel 已废弃，请改用 calculate_multiple_indicators_polars",
        DeprecationWarning,
        stacklevel=2,
    )

    if not isinstance(data, pl.DataFrame):
        data = pl.from_pandas(data)

    # 保留预处理以维持旧 API 的输入宽容度；已预处理的数据走幂等快速路径
    data = preprocess_data_polars(data)

    return calculate_multiple_indicators_polars(data, indicator_types, optimize_memory=optimize_memory, **params)
