# 消除技术指标链路 Pandas↔Polars 反复转换开销

## Context

技术指标核心已用 Polars 实现，但计算链路中仍存在高频格式往返：每算一个指标就 `pl.from_pandas(df)`，算完又 `to_pandas()` 交回 UI/策略层；渲染层每个指标各自新建 `TechnicalAnalyzer`（重复全量预处理+哈希）或逐次调用 `calculate_indicator`（每次重跑全量 preprocess）。内存拷贝开销已超过向量化计算本身。

**改造原则**：Polars 为计算链路唯一规范格式，转换只发生在两个边界——数据入口一次性 `from_pandas`；绘图出口按列 `to_numpy()`（数值列近零拷贝，保留不动）。

**已核实的调用方事实**（决定改动安全性）：
- `calculate_all_indicators` 全项目仅 2 个生产调用方：[async_processing.py:198](file:///d:/code/python/quant/src/ui/async_processing.py#L198)（返回值未使用）、[main_window_data_mixin.py:1032](file:///d:/code/python/quant/src/ui/main_window_data_mixin.py#L1032)（已显式传 `return_polars=True`）→ 翻默认安全。
- `IndicatorManager.calculate_indicator/calculate_indicators` 所有显式调用方（renderer 10 处、streaming_processor 2 处、technical_analyzer 2 处）均已传 `return_polars=True` → 翻默认安全。
- 策略层 [strategy_analyzer.py](file:///d:/code/python/quant/src/strategy/analyzer/strategy_analyzer.py) 已用 `get_data()` 默认返回 Polars，无需改动。
- 渲染主流程 [main_window_drawing_mixin.py](file:///d:/code/python/quant/src/ui/main_window_drawing_mixin.py) 已是 Polars 端到端（`df_pl`）。

## 实施步骤

### P0：渲染前置批量计算（收益最大）

**文件**：[main_window_drawing_mixin.py](file:///d:/code/python/quant/src/ui/main_window_drawing_mixin.py)、[indicator_renderer.py](file:///d:/code/python/quant/src/ui/chart_components/indicator_renderer.py)

1. 新增共享常量 `INDICATOR_PARAM_MAP`（放 indicator_renderer.py 或独立小模块）：UI 指标名（'MACD'/'KDJ'/'EXPMA'/...）→（指标类型， 默认参数），与 `render_indicator` 的 renderers 表（L1673-1709）保持一致。
2. 在 `_plot_k_line_impl`（L106-140）渲染前新增 `_ensure_indicators(df_pl)` 步骤：
   - 汇总 `window_indicators`（副图窗口）+ 主图叠加勾选状态（SAR/BOLL 等）所需的全部指标类型与参数；
   - 检查 `df_pl.columns` 找出缺失列对应的指标；
   - 若有缺失，调用一次 `calculate_multiple_indicators_polars(df_pl.lazy(), missing_types, **params)` 单查询计划算齐，collect 后替换 df_pl。
3. render_* 方法退化为纯绘图：
   - 删除其中 `TechnicalAnalyzer(df)` 新建（render_macd L383、render_kdj 等约 20 处）和 `global_indicator_manager.calculate_indicator(...)` 逐指标调用（render_expma L1337、render_bbi L1376 等 10 处）；
   - 列仍缺失时仅记 warning 并跳过该指标绘制（不再现场计算），保留 `to_numpy()` 绘图出口。

**风险**：指标名→类型/参数映射与现有默认参数不一致会导致曲线形态变化。缓解：映射表参数逐一比对现有 render_* 内的调用参数（如 EXPMA windows=[12,50]、LB period=5、CYC windows=[5,13,34]、CYS cyc_window=13、ABI/ADR/OBOS period=10）。

### P1：返回格式默认值翻转

**文件**：[technical_analyzer.py:1588](file:///d:/code/python/quant/src/tech_analysis/technical_analyzer.py#L1588)、[indicator_manager.py](file:///d:/code/python/quant/src/tech_analysis/indicator_manager.py)

1. `calculate_all_indicators`：`params.get('return_polars', False)` → `True`。
2. `IndicatorManager.calculate_indicator`(L427) 与 `calculate_indicators`(L468)：`return_polars: bool = False` → `True`。
3. 保留显式传 False 的能力不变；更新两处方法的 docstring 默认值描述。

**风险**：文档示例（event_driven_architecture.md）与潜在外部动态调用。缓解：翻转后跑全量测试；文档示例不构成功能影响。

### P2：preprocess_data_polars 幂等快速路径

**文件**：[indicator_calculator.py:65](file:///d:/code/python/quant/src/tech_analysis/indicator_calculator.py#L65)

在 `preprocess_data_polars` 入口增加快速跳过：若全部数值列已是目标 dtype（Float32/Int32/Int16/Int8）且数值列无 NaN（用 `pl.all_horizontal` 或按列 null_count 汇总判断，均为向量化廉价操作），直接返回原 df，跳过 `MemoryOptimizer.optimize_dataframe` + `fill_nan` 全量扫描。

**风险**：误判跳过必要填充。缓解：校验条件从严——任一列 dtype 不符或存在 NaN 即走完整预处理，宁多算不错过。

### P3：遗留插件路径瘦身

**文件**：[technical_analyzer.py:935-943](file:///d:/code/python/quant/src/tech_analysis/technical_analyzer.py#L935)、[plugin_base.py:724](file:///d:/code/python/quant/src/plugin/plugin_base.py#L724)

1. `calculate_plugin_indicator` 遗留 pandas 路径：`self.pl_df.to_pandas()` 前先 `select` 必需列（date/open/high/low/close/volume + 插件声明的输入依赖列），避免把几十列已算指标一起拷贝。
2. `PluginBase` 新增可选类属性 `required_columns: List[str] = None`（None 表示未声明，回退全量转换，保证兼容）；`calculate_polars` shim 同样按声明列裁剪后再 to_pandas。
3. `calculate_plugin_indicators`（并行批量入口，L1380 附近）：同批遗留插件共享一份裁剪后的 pandas 副本，避免每插件一次全量往返。

**风险**：插件隐式依赖未声明列。缓解：`required_columns` 缺省回退全量转换，只有显式声明的插件才裁剪。

## 明确不做

- 不改 strategy_analyzer / streaming_processor（已全 Polars，to_numpy 仅 GPU 路径）。
- 不优化绘图出口的按列 `to_numpy()`（数值列近零拷贝，无收益）。
- 不强制遗留插件改写为 Polars 原生（成本高，列裁剪已够）。
- 不动 global_indicator_cache 的哈希机制（现有采样哈希可用）。

## 验证方案

1. **回归测试**：`pytest tests/` 全量（当前基线 49 项全绿），为 P1 默认值翻转与 P2 快速路径补充单测。
2. **转换计数**：用 monkeypatch 统计 `pl.from_pandas` / `DataFrame.to_pandas` 在一次 `_plot_k_line_impl` 全流程中的调用次数——目标：渲染路径（render_* 及 calculate_indicator）为 0 次全量往返；并计时对比改造前后渲染耗时。
3. **端到端一致性**：固定股票/区间，改造前后对全部勾选指标逐一目视比对曲线形态；导出结果 DataFrame 对关键指标列做数值一致性校验（允许浮点误差内 allclose）。
