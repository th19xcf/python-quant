# 指标计算与渲染 Python 级循环热点优化计划

## Context（背景）

静态分析标记 `technical_analyzer.py`（78KB）与 `indicator_renderer.py`（75KB）存在「Python 级循环热点」性能问题（🟠 高）。经逐文件核实：

- **technical_analyzer.py 本身无热点**：其循环均为指标数/列数级别的编排循环（≤几十次迭代），计算已全部委托 Polars 向量化路径。真正的逐 bar O(n) Python 循环在 `gpu_acceleration.py`（GPU 可用时被 technical_analyzer L1158 分支调用）。
- **indicator_renderer.py 确有 6 处渲染热点**：逐 K 线创建 `BarGraphItem`/`PlotDataItem` 并逐个 `addItem`，每个指标窗口产生数百至上千个 QGraphicsItem，是 UI 卡顿主因。

用户决策：GPU 路径采用**就地修复**（保留接口与缓存行为，仅替换循环实现）。

## 修改点 A：gpu_acceleration.py 三处递推循环就地修复

文件：`src/tech_analysis/gpu_acceleration.py`

### A1. MACD 内嵌 EMA 循环（L151-157）→ pandas ewm 向量化

现状：逐元素写 cupy 数组，每个元素一次 CUDA kernel 启动。
语义：`y[0]=x[0]; y[i]=alpha*x[i]+(1-alpha)*y[i-1]`，`alpha=2/(p+1)` —— 与 `pandas.Series.ewm(span=p, adjust=False).mean()` 完全一致。

改法：删除内嵌 `ema()` 循环函数，改用 pandas ewm 在 CPU 侧计算 EMA（递推类指标 GPU 无收益），`macd_line/signal/hist` 的减法保持现有 cupy 向量化运算不变。

### A2. RSI 内嵌 Wilder SMA 循环（L199-204）→ Numba @njit

现状：带种子递推（种子 = 前 window 项均值，之后 `y[i]=(y[i-1]*(w-1)+x[i])/w`），pandas ewm 无法精确复现种子语义。

改法：新增模块级 `@njit(cache=True)` 辅助函数 `_wilder_sma_core(data, window)`，逐行保留现有种子与递推语义；RSI 的 gain/loss/RS 计算保持现有 cupy 向量化部分，仅将 SMA 段改为「`to_cpu` → numba → 结果回传」。遵循项目先例 `src/tech_analysis/indicators/trend.py:36` `_sar_core`。

### A3. SAR 纯 Python 循环（L218-297）→ 委托现有 `_sar_core`

现状：纯 Python/NumPy 循环，**未使用 cupy**；逐行比对确认与 `src/tech_analysis/indicators/trend.py` 的 `_sar_core` 算法（种子、限幅、反转、EP/AF 更新）完全一致。

改法：`calculate_sar_gpu` 方法体改为直接调用 `_sar_core(high, low, close, af_step, max_af)`，删除本文件内的循环副本。不新增 Numba 代码，纯复用。

## 修改点 B：indicator_renderer.py 六处渲染批量化

文件：`src/ui/chart_components/indicator_renderer.py`

借鉴先例：主图 `src/ui/chart_items.py` `CandleStickItem`（L17-191）单 GraphicsObject 批量绘制模式。指标层采用更轻量方案：

| 热点 | 行号 | 改法 |
|---|---|---|
| `_draw_volume_bars` | L321-341 | 单 `pg.BarGraphItem(x=arr, height=arr, width=0.8, brushes=颜色数组)`，颜色用 numpy 向量化生成（`np.where(close>=open, 红, 绿)`） |
| `_draw_macd_histogram` | L516-534 | 同上，`brushes` 按 sign 数组化 |
| `render_vol_tdx` | L1303-1307 | 颜色列表推导改 numpy 向量化；逐根竖线 plot 改为按颜色分组（≤2 组），每组构造 NaN 分隔的 x/y 数组，单 `PlotCurveItem(connect='finite')` |
| `render_hsl` | L1412-1420 | 同上，按颜色分组 |
| `render_lb` | L1455-1467 | 同上，5 档颜色 → ≤5 个 CurveItem |
| `render_cys` | L1528-1531 | 同上 |

效果：每窗口 scene item 数从 O(K线数) 降为 O(颜色数)，≤5 个。

通用模式（新增一个私有辅助方法，如 `_draw_colored_vertical_lines(plot_widget, x, heights, color_idx_map)`）：输入 x 数组、高度数组、每根的颜色分组号，输出按组构建 NaN 分隔数组并各加一个 `PlotCurveItem`，避免 4 处重复代码。

## 不做的修改

- 不动 `technical_analyzer.py` 的 GPU 分支调用逻辑、缓存与状态跟踪代码
- 不动 Polars CPU 主路径与 `indicator_calculator.py`
- 不动 `CandleStickItem` 主图渲染

## 验证

1. **数值一致性（修改前后对照）**：编写一次性验证脚本（放 `scripts/` 或临时文件，不入库），用同一样本数据（如 600000 日线）分别运行旧实现与新实现，断言 MACD/RSI/SAR 输出 `np.allclose(equal_nan=True)`。在改代码**之前**先跑一次旧实现保存基准。
2. **回归测试**：运行现有全量测试套件（此前基线 124 passed），确保全部通过。
3. **渲染冒烟**：启动应用打开带 VOL/MACD/VOL-TDX/HSL/LB/CYS 指标的 K 线图，肉眼确认柱状图颜色与形态与修改前一致；可对比修改前后 `scene().items()` 数量验证 item 数下降。
4. 若无 GPU 环境，GPU 路径修改通过临时 mock `is_gpu_available()` 返回 True 的方式在验证脚本中覆盖。

## 提交要求

按 `.trae/rules/project_rules.md`：先同步修改文件至 `E:\git\python-quant\` 备份目录并校验 SHA256，展示待提交清单与 commit message，等待用户确认后再提交。
